from pathlib import Path
import argparse
import json
import math
import warnings
from statistics import NormalDist

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from src.preprocess_utils import load_and_prepare, fold_preprocess
from src.model_utils import fit_proposed, set_epan
from src import rmave_empirical_v2 as r2


ROOT = Path(__file__).resolve().parent
EPS = 1.0e-12
MANUAL_H_PROPOSED = h_proposed


def epan_kernel(q):
    q = np.asarray(q, float)
    return 0.75 * np.maximum(1.0 - q * q, 0.0) * (np.abs(q) <= 1.0)


def epan_kh(delta, h):
    if h <= 0:
        raise ValueError("h must be positive")
    return epan_kernel(np.asarray(delta, float) / h) / h


def epan_constants():

    # K(u)=3/4(1-u^2) 1{|u|<=1}
    # mu_2 = integral u^2 K(u)du = 1/5
    # R(K) = integral K(u)^2 du = 3/5
    return 1.0 / 5.0, 3.0 / 5.0


def parse_station_indices(text, n):
    ans = [int(x.strip()) for x in text.split(',') if x.strip()]
    if not ans:
        raise ValueError('station-idx is empty')
    if any(x < 1 or x > n for x in ans):
        raise ValueError(f'station indices must be in 1,...,{n}')
    return [x - 1 for x in ans]


def load_or_refit_proposed(y, x, z, h, refit=False, max_iter=300, tol=1e-6):
    """Load theta/beta saved by 04 when possible; otherwise refit Proposed."""
    set_epan()
    (ys, xs, zs), scale = r2.scale_train(y, x, z)
    parfile = ROOT / 'results' / 'fixed_h_parameters.csv'
    metricfile = ROOT / 'results' / 'fixed_h_train_test_metrics.csv'
    can_load = (not refit) and parfile.exists() and metricfile.exists()
    if can_load:
        mt = pd.read_csv(metricfile)
        mr = mt[(mt['method'] == 'Proposed') & mt['sample'].astype(str).str.contains('train')]
        h04 = float(mr.iloc[0]['h']) if len(mr) else np.nan
        if (not np.isfinite(h04)) or (not np.isclose(h04, h, rtol=0, atol=1e-12)):
            warnings.warn(f'04 used h={h04}, requested h={h}; Proposed will be refitted.')
            can_load = False
    if can_load:
        pt = pd.read_csv(parfile)
        row = pt[pt['method'] == 'Proposed']
        if len(row) == 1:
            beta = np.asarray(json.loads(row.iloc[0]['beta']), float)
            theta = np.asarray(json.loads(row.iloc[0]['theta']), float)
            return {
                'beta': beta,
                'theta': theta,
                'scale': scale,
                'loaded_from_04': True,
                'iterations': np.nan,
                'converged': True,
            }, ys, xs, zs
    fit = fit_proposed(y, x, z, h, max_iter=max_iter, tol=tol, full_starts=False)
    fit['loaded_from_04'] = False
    return fit, ys, xs, zs


def local_quadratic_second_derivative(u, y, u0, h):
    """Pilot local-quadratic estimate of g''(u0), used only for optional bias correction."""
    d = np.asarray(u, float) - float(u0)
    w = epan_kh(d, h)
    D = np.column_stack([np.ones_like(d), d, d*d])
    A = D.T @ (w[:, None] * D)
    ridge = 1e-10 * max(float(np.trace(A)), 1.0)
    coef = np.linalg.pinv(A + ridge*np.eye(3), rcond=1e-10) @ (D.T @ (w*y))
    return 2.0 * float(coef[2])


def infer_at_observed_points(u, partial, ghat, h, bias_bandwidth_factor=1.5):
    """Pointwise inference for one station at observed index values.

    Theorem 4.3 plug-in standard error:

        se_g(u) = sqrt[ sigma_i^2 R(K) / {T h f_i(u)} ].

    A second exact local-linear equivalent-weight SE is returned as a diagnostic.

    The prediction SE for the partial response adds the idiosyncratic variance:

        se_pred(u) = sqrt[ sigma_i^2 + se_g(u)^2 ].

    """
    u = np.asarray(u, float).reshape(-1)
    partial = np.asarray(partial, float).reshape(-1)
    ghat = np.asarray(ghat, float).reshape(-1)
    T = len(u)
    resid = partial - ghat

    # Plug-in estimate of sigma_i^2 in Theorem 4.3.
    sigma2 = float(np.mean(resid**2))
    mu2, Rk = epan_constants()
    fhat = np.full(T, np.nan)
    effective_n = np.full(T, np.nan)
    se_theorem = np.full(T, np.nan)
    se_ll = np.full(T, np.nan)
    g2 = np.full(T, np.nan)
    for s, u0 in enumerate(u):
        d = u - u0
        w = epan_kh(d, h)
        s0 = float(np.sum(w))
        s1 = float(np.sum(w*d))
        s2 = float(np.sum(w*d*d))
        sw2 = float(np.sum(w*w))
        if s0 <= EPS:
            continue
        fhat[s] = s0 / T
        effective_n[s] = s0*s0 / max(sw2, EPS)
        se_theorem[s] = math.sqrt(max(sigma2 * Rk / (T*h*max(fhat[s], EPS)), 0.0))
        # Exact local-linear equivalent weights for the intercept at u0.
        ridge = 1e-10 * max(s0+s2, 1.0)
        A = np.array([[s0+ridge, s1], [s1, s2+ridge]], float)
        Ainv = np.linalg.pinv(A, rcond=1e-10)
        D = np.column_stack([np.ones(T), d])
        lvec = np.array([1.0, 0.0]) @ Ainv @ (D.T * w)
        se_ll[s] = math.sqrt(max(sigma2 * float(np.sum(lvec*lvec)), 0.0))
        hb = h * float(bias_bandwidth_factor)
        g2[s] = local_quadratic_second_derivative(u, partial, u0, hb)
    bias = 0.5 * mu2 * h*h * g2
    return {
        'resid': resid,
        'sigma2': sigma2,
        'fhat': fhat,
        'effective_n': effective_n,
        'se_theorem': se_theorem,
        'se_local_linear': se_ll,
        'g2': g2,
        'bias': bias,
        'mu2': mu2,
        'Rk': Rk,
    }


def main():
    ap = argparse.ArgumentParser(
        description='UK Proposed-link inference for reviewer response: pointwise CI for g_i and prediction interval for partial response.'
    )
    ap.add_argument('--station-idx', default='3,4,11', help='1-based station indices')

    ap.add_argument('--alpha', type=float, default=0.05)
    ap.add_argument('--ci-se', choices=['theorem', 'local-linear'], default='theorem')
    bias_flags = ap.add_mutually_exclusive_group()
    bias_flags.add_argument('--bias-corrected', dest='bias_corrected',
                            action='store_true', default=True,
                            help='Use leading-bias correction (default; kept for compatibility).')
    bias_flags.add_argument('--no-bias-correction', dest='bias_corrected',
                            action='store_false',
                            help='Plot intervals centered at uncorrected g-hat.')
    ap.add_argument('--bias-bandwidth-factor', type=float, default=1.5)
    ap.add_argument('--refit', action='store_true')
    ap.add_argument('--max-iter', type=int, default=300)
    ap.add_argument('--tol', type=float, default=1e-6)
    ap.add_argument('--min-effective', type=float, default=2.0)
    args = ap.parse_args()
    if not 0 < args.alpha < 1:
        ap.error('--alpha must be strictly between 0 and 1')
    if not np.isfinite(args.bias_bandwidth_factor) or args.bias_bandwidth_factor <= 0:
        ap.error('--bias-bandwidth-factor must be positive')
    h = float(MANUAL_H_PROPOSED)
    if not np.isfinite(h) or h <= 0:
        raise ValueError("MANUAL_H_PROPOSED must be a finite positive number")
    h_source = "MANUAL_H_PROPOSED in this CI script"

    # Normal critical value for the requested two-sided confidence level.
    zcrit = NormalDist().inv_cdf(1.0 - args.alpha / 2.0)

    # Same final design as 04. Test 2008 is NOT used for inference.
    df = load_and_prepare(ROOT / 'data' / 'uk16.csv')
    d = fold_preprocess(df, 2007, 2008, x_cols=('sun','rain'))
    y, x, z = d['y_train'], d['x_train'], d['z_train']
    stations = d['stations']
    selected = parse_station_indices(args.station_idx, len(stations))
    fit, ys, xs, zs = load_or_refit_proposed(
        y, x, z, h, refit=args.refit, max_iter=args.max_iter, tol=args.tol
    )
    beta = np.asarray(fit['beta'], float)
    theta = np.asarray(fit['theta'], float)

    # IMPORTANT MODEL IDENTITIES:
    # index u_it          = theta_hat' X_it
    # partial response   = Y_it - beta_hat' Z_it
    # fitted partial     = g_hat_i(u_it)
    # model residual     = partial response - fitted partial
    # There is NO subtraction of theta_hat'X_it from Y unless g(u)=u is imposed.
    u_all = np.einsum('ntp,p->nt', xs, theta)
    partial_std = ys - np.einsum('ntd,d->nt', zs, beta)
    set_epan()
    gobs_std, _, effective_rmave = r2.local_links(u_all, partial_std, h)
    y_mean = float(fit['scale']['y_mean'])
    y_sd = float(fit['scale']['y_sd'])
    outdir = ROOT / 'results' / 'proposed_inference_reviewer'
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    summary_rows = []
    confidence_label = f'{100*(1-args.alpha):g}CI'
    suffix = f"{args.ci_se}_leadingbias_h{h:g}"
    if not args.bias_corrected:
        suffix += '_uncorrected'
    if not np.isclose(args.alpha, 0.05):
        suffix += f'_alpha{args.alpha:g}'
    for i in selected:
        inf = infer_at_observed_points(
            u_all[i], partial_std[i], gobs_std[i], h,
            bias_bandwidth_factor=args.bias_bandwidth_factor
        )
        se_g_std = inf['se_theorem'] if args.ci_se == 'theorem' else inf['se_local_linear']
        center_std = (gobs_std[i] - inf['bias']) if args.bias_corrected else gobs_std[i]
        ci_lo_std = center_std - zcrit*se_g_std
        ci_hi_std = center_std + zcrit*se_g_std
        # Prediction interval for a NEW partial response at the same index.
        # This is NOT the confidence interval for g_i(u).
        pred_se_std = np.sqrt(np.maximum(inf['sigma2'] + se_g_std**2, 0.0))
        pi_lo_std = center_std - zcrit*pred_se_std
        pi_hi_std = center_std + zcrit*pred_se_std
        # Back to the adjusted TMAX scale used in the empirical application.
        partial = y_mean + y_sd*partial_std[i]
        ghat = y_mean + y_sd*gobs_std[i]
        center = y_mean + y_sd*center_std
        corrected_ghat = y_mean + y_sd*(gobs_std[i] - inf['bias'])
        ci_lo = y_mean + y_sd*ci_lo_std
        ci_hi = y_mean + y_sd*ci_hi_std
        pi_lo = y_mean + y_sd*pi_lo_std
        pi_hi = y_mean + y_sd*pi_hi_std
        model_resid = y_sd*inf['resid']
        se_g = y_sd*se_g_std
        pred_se = y_sd*pred_se_std
        order = np.argsort(u_all[i])
        us = u_all[i][order]
        cil = ci_lo[order]; cih = ci_hi[order]
        center_sorted = center[order]
        pil = pi_lo[order]; pih = pi_hi[order]
        eff = inf['effective_n'][order]
        valid = np.isfinite(center_sorted) & np.isfinite(cil) & np.isfinite(cih) & (eff >= args.min_effective)
        valid_pi = valid & np.isfinite(pil) & np.isfinite(pih)
        # Figure 1: manuscript/reviewer target -- CI for the mean link only.
        fig_ci, a = plt.subplots(1, 1, figsize=(8.2, 3.75))
        a.scatter(u_all[i], partial, s=15, c='red', alpha=0.72, edgecolors='none')
        a.plot(us[valid], center_sorted[valid], 'k-', lw=1.25)
        a.plot(us[valid], cil[valid], color='black', ls='-.', lw=1.05)
        a.plot(us[valid], cih[valid], color='black', ls='-.', lw=1.05)
        fig_ci.tight_layout()
        # Figure 2: diagnostic -- adds prediction interval for observations.
        fig_pi, b = plt.subplots(1, 1, figsize=(8.2, 3.75))
        b.scatter(u_all[i], partial, s=15, c='red', alpha=0.72, edgecolors='none')
        b.plot(us[valid], center_sorted[valid], 'k-', lw=1.25)
        b.plot(us[valid], cil[valid], color='black', ls='-.', lw=1.0)
        b.plot(us[valid], cih[valid], color='black', ls='-.', lw=1.0)
        b.plot(us[valid_pi], pil[valid_pi], color='0.45', ls='--', lw=1.05)
        b.plot(us[valid_pi], pih[valid_pi], color='0.45', ls='--', lw=1.05)
        fig_pi.tight_layout()
        # Observation containment is meaningful for PI, NOT for CI.
        in_ci = np.isfinite(ci_lo) & np.isfinite(ci_hi) & (partial >= ci_lo) & (partial <= ci_hi)
        in_pi = np.isfinite(pi_lo) & np.isfinite(pi_hi) & (partial >= pi_lo) & (partial <= pi_hi)
        summary_rows.append({
            'station_index': i+1,
            'station': stations[i],
            'T_train': len(partial),
            'h': h,
            'sigma_hat': y_sd*math.sqrt(max(inf['sigma2'], 0.0)),
            'mean_link_CI_width': float(np.nanmean(ci_hi-ci_lo)),
            'mean_prediction_interval_width': float(np.nanmean(pi_hi-pi_lo)),
            'fraction_observed_partial_response_inside_link_CI_NOT_A_COVERAGE_TARGET': float(np.mean(in_ci)),
            'fraction_observed_partial_response_inside_prediction_interval': float(np.mean(in_pi)),
        })
        rows.append(pd.DataFrame({
            'station_index': i+1,
            'station': stations[i],
            'time_order': np.arange(1, len(partial)+1),
            'u_thetaX': u_all[i],
            'partial_response_Y_minus_betaZ': partial,
            'g_hat_raw': ghat,
            'g_hat_bias_corrected': corrected_ghat,
            'g_hat_CI_center': center,
            'model_residual_Y_minus_betaZ_minus_g': model_resid,
            'se_link': se_g,
            'ci_link_lower': ci_lo,
            'ci_link_upper': ci_hi,
            'prediction_se_partial_response': pred_se,
            'prediction_lower': pi_lo,
            'prediction_upper': pi_hi,
            'f_hat': inf['fhat'],
            'effective_n': inf['effective_n'],
            'effective_n_rmave': effective_rmave[i],
            'bias_hat': y_sd*inf['bias'],
            'h': h,
        }))
        f_ci = outdir / f'UK_proposed_link_{confidence_label}_{suffix}_station_{i+1}.png'
        f_pi = outdir / f'UK_proposed_link_{confidence_label}_plus_prediction_interval_{suffix}_station_{i+1}.png'
        fig_ci.savefig(f_ci, dpi=240, bbox_inches='tight')
        fig_pi.savefig(f_pi, dpi=240, bbox_inches='tight')
        plt.close(fig_ci); plt.close(fig_pi)
    f_csv = outdir / f'UK_proposed_inference_points_{suffix}.csv'
    f_sum = outdir / f'UK_proposed_inference_summary_{suffix}.csv'
    f_meta = outdir / f'UK_proposed_inference_metadata_{suffix}.csv'
    pd.concat(rows, ignore_index=True).to_csv(f_csv, index=False)
    pd.DataFrame(summary_rows).to_csv(f_sum, index=False)
    pd.DataFrame([{
        'train_period': '1999-01--2007-12',
        'test_period_excluded_from_inference': '2008-01--2008-12',
        'model': 'Y_it = g_i(theta^T X_it) + beta^T Z_it + e_it',
        'x_axis': 'theta_hat^T X_it',
        'red_points': 'Y_it - beta_hat^T Z_it',
        'fitted_residual': 'Y_it - beta_hat^T Z_it - g_hat_i(theta_hat^T X_it)',
        'explicitly_NOT_used': 'Y_it - theta_hat^T X_it - beta_hat^T Z_it',
        'h_proposed': h,
        'h_source': h_source,
        'kernel': 'Epanechnikov',
        'link_interval': f'{confidence_label} pointwise confidence interval for g_i(u)',
        'prediction_interval': f'{confidence_label} pointwise prediction interval for a new partial response Y-betaZ',
        'ci_se': args.ci_se,
        'bias_corrected': args.bias_corrected,
        'alpha': args.alpha,
        'mu2_K': epan_constants()[0],
        'R_K': epan_constants()[1],
        'theta_beta_source': '04 saved estimates' if fit.get('loaded_from_04') else 'refit Proposed',
        'leading_bias': '0.5 * mu2(K) * h^2 * g2_hat(u)',
        'g2_estimator': 'local quadratic, pilot bandwidth = bias_bandwidth_factor * h',
        'extra_smoothing': 'none; no LOWESS/spline',
    }]).to_csv(f_meta, index=False)
    print('\nCompleted UK Proposed inference.')
    print(f'h = {h} ({h_source})')
    print('Red dots are Y - beta_hat^T Z; NOT Y - theta_hat^T X - beta_hat^T Z.')
    print('The mean-link CI is not a coverage target for individual observed partial responses.')
    print('Use the prediction interval figure when assessing observation containment.')
    print(f'Pointwise values: {f_csv}')
    print(f'Summary: {f_sum}')


if __name__ == '__main__':
    main()
