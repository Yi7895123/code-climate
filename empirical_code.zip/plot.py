from pathlib import Path

import argparse

import json

import math

import warnings

from statistics import NormalDist



import numpy as np

import pandas as pd

import matplotlib.pyplot as plt



from src.preprocess_utils import load_and_prepare, fold_preprocess

from src.model_utils import fit_proposed, set_epan

from src import rmave_empirical_v2 as r2



ROOT = Path(__file__).resolve().parent

EPS = 1.0e-12



MANUAL_H_PROPOSED = h_proposed
HAC_LAGS = None  # None: floor(T_train**0.25)








def epan_kernel(q):

    q = np.asarray(q, float)

    return 0.75 * np.maximum(1.0 - q * q, 0.0) * (np.abs(q) <= 1.0)





def epan_kh(delta, h):

    if h <= 0:

        raise ValueError("h must be positive")

    return epan_kernel(np.asarray(delta, float) / h) / h





def epan_constants():

    # K(u)=3/4(1-u^2) 1{|u|<=1}

    # mu_2 = integral u^2 K(u)du = 1/5

    # R(K) = integral K(u)^2 du = 3/5

    return 1.0 / 5.0, 3.0 / 5.0





def parse_station_indices(text, n):

    ans = [int(x.strip()) for x in text.split(',') if x.strip()]

    if not ans:

        raise ValueError('station-idx is empty')

    if any(x < 1 or x > n for x in ans):

        raise ValueError(f'station indices must be in 1,...,{n}')

    return [x - 1 for x in ans]





def load_or_refit_proposed(y, x, z, h, refit=False, max_iter=300, tol=1e-6):

    """Load theta/beta saved by 04 when possible; otherwise refit Proposed."""

    set_epan()

    (ys, xs, zs), scale = r2.scale_train(y, x, z)



    parfile = ROOT / 'results' / 'fixed_h_parameters.csv'

    metricfile = ROOT / 'results' / 'fixed_h_train_test_metrics.csv'

    can_load = (not refit) and parfile.exists() and metricfile.exists()



    if can_load:

        mt = pd.read_csv(metricfile)

        mr = mt[(mt['method'] == 'Proposed') & mt['sample'].astype(str).str.contains('train')]

        h04 = float(mr.iloc[0]['h']) if len(mr) else np.nan

        if (not np.isfinite(h04)) or (not np.isclose(h04, h, rtol=0, atol=1e-12)):

            warnings.warn(f'04 used h={h04}, requested h={h}; Proposed will be refitted.')

            can_load = False



    if can_load:

        pt = pd.read_csv(parfile)

        row = pt[pt['method'] == 'Proposed']

        if len(row) == 1:

            beta = np.asarray(json.loads(row.iloc[0]['beta']), float)

            theta = np.asarray(json.loads(row.iloc[0]['theta']), float)

            return {

                'beta': beta,

                'theta': theta,

                'scale': scale,

                'loaded_from_04': True,

                'iterations': np.nan,

                'converged': True,

            }, ys, xs, zs



    fit = fit_proposed(y, x, z, h, max_iter=max_iter, tol=tol, full_starts=False)

    fit['loaded_from_04'] = False

    return fit, ys, xs, zs





def local_quadratic_second_derivative(u, partial, u0, pilot_h):
    """Rescaled local-quadratic estimate of the second derivative g''(u0)."""
    u = np.asarray(u, float).reshape(-1)
    partial = np.asarray(partial, float).reshape(-1)
    v = (u - float(u0)) / float(pilot_h)
    w = epan_kernel(v)
    valid = np.isfinite(v) & np.isfinite(partial) & (w > 0)

    if np.sum(valid) < 3:
        return np.nan

    vv = v[valid]
    ww = w[valid]
    yy = partial[valid]
    D = np.column_stack([np.ones_like(vv), vv, vv ** 2])

    sqrt_w = np.sqrt(ww)
    A = D * sqrt_w[:, None]
    b = yy * sqrt_w
    coef, _, rank, _ = np.linalg.lstsq(A, b, rcond=None)

    if rank < 3:
        return np.nan

    return 2.0 * float(coef[2]) / float(pilot_h) ** 2


def local_linear_intercept_weights(u, u0, h):
    """Exact intercept weights for the local-linear smoother at u0."""
    delta = np.asarray(u, float) - float(u0)
    w = epan_kh(delta, h)
    s0 = float(np.sum(w))
    s1 = float(np.dot(w, delta))
    s2 = float(np.dot(w, delta * delta))
    ridge = 1.0e-10 * max(s0 + s2, 1.0)
    den = max((s0 + ridge) * (s2 + ridge) - s1 * s1, EPS)
    return w * (s2 + ridge - s1 * delta) / den


def residual_autocovariances(resid, lags):
    """Biased stationary autocovariances with denominator T."""
    r = np.asarray(resid, float).reshape(-1)
    r = r - np.mean(r)
    T = len(r)
    return np.array([
        float(np.dot(r[lag:], r[:T-lag]) / T)
        for lag in range(lags + 1)
    ])


def infer_at_observed_points(
    u, partial, ghat, h, bias_bandwidth_factor=1.5, hac_lags=3
):
    """Bias-corrected pointwise link inference using Bartlett time-HAC variance.

    The link-estimation variance is calculated from the exact local-linear
    intercept weights and the within-station residual autocovariances.
    The prediction variance is for one month beyond the training sample and
    includes the covariance between the future error and the fitted link.
    """
    u = np.asarray(u, float).reshape(-1)
    partial = np.asarray(partial, float).reshape(-1)
    ghat = np.asarray(ghat, float).reshape(-1)
    T = len(u)

    if T != len(partial) or T != len(ghat):
        raise ValueError("u, partial and ghat must have the same length.")
    if T < 5 or h <= 0 or bias_bandwidth_factor <= 0:
        raise ValueError("At least five observations and positive bandwidths are required.")
    if not 0 <= hac_lags < T:
        raise ValueError("hac_lags must be between 0 and T-1.")

    resid = partial - ghat
    gamma = residual_autocovariances(resid, hac_lags)
    sigma2 = float(gamma[0])
    mu2, Rk = epan_constants()

    fhat = np.full(T, np.nan)
    effective_n = np.full(T, np.nan)
    vhat_iid_theorem = np.full(T, np.nan)
    vhat_iid_local = np.full(T, np.nan)
    vhat_hac = np.full(T, np.nan)
    covariance_future = np.full(T, np.nan)
    pred_var_next = np.full(T, np.nan)
    g2 = np.full(T, np.nan)
    pilot_h = h * float(bias_bandwidth_factor)

    for s, u0 in enumerate(u):
        w = epan_kh(u - u0, h)
        s0 = float(np.sum(w))
        sw2 = float(np.sum(w ** 2))
        if s0 <= EPS:
            continue

        fhat[s] = s0 / T
        effective_n[s] = s0 ** 2 / max(sw2, EPS)

        # IID leading-order Theorem 4.3 variance, retained for comparison.
        vhat_iid_theorem[s] = sigma2 * Rk / (T * h * max(fhat[s], EPS))

        # Exact local-linear equivalent weights.
        ell = local_linear_intercept_weights(u, u0, h)
        vhat_iid_local[s] = sigma2 * float(np.dot(ell, ell))

        # Bartlett HAC variance for the same local-linear intercept.
        v = vhat_iid_local[s]
        for lag in range(1, hac_lags + 1):
            bartlett = 1.0 - lag / (hac_lags + 1.0)
            v += (
                2.0 * bartlett * gamma[lag]
                * float(np.dot(ell[lag:], ell[:-lag]))
            )
        vhat_hac[s] = max(float(v), 0.0)

        # Covariance of e_{T+1} with the fitted link estimation error.
        covariance_future[s] = sum(
            float(gamma[lag] * ell[-lag])
            for lag in range(1, hac_lags + 1)
        )
        pred_var_next[s] = max(
            sigma2 + vhat_hac[s] - 2.0 * covariance_future[s],
            0.0
        )

        g2[s] = local_quadratic_second_derivative(
            u, partial, u0, pilot_h
        )

    bias = 0.5 * mu2 * h ** 2 * g2
    return {
        "resid": resid,
        "sigma2": sigma2,
        "gamma": gamma,
        "hac_lags": hac_lags,
        "fhat": fhat,
        "effective_n": effective_n,
        "vhat_iid_theorem": vhat_iid_theorem,
        "vhat_iid_local": vhat_iid_local,
        "vhat_hac": vhat_hac,
        "vhat": vhat_hac,
        "se_hac": np.sqrt(np.maximum(vhat_hac, 0.0)),
        "se_iid_theorem": np.sqrt(np.maximum(vhat_iid_theorem, 0.0)),
        "g2": g2,
        "bias": bias,
        "center": ghat - bias,
        "mu2": mu2,
        "Rk": Rk,
        "pilot_h": pilot_h,
        "covariance_next_error_and_link_estimate": covariance_future,
        "prediction_variance_next_month": pred_var_next,
    }



def main():

    ap = argparse.ArgumentParser(

        description='UK Proposed link inference: bias-corrected pointwise confidence intervals with Bartlett HAC variance.'

    )
    
    ap.add_argument('--station-idx', default='3,5,7,8,9,10', help='1-based station indices')
    #ap.add_argument('--station-idx', default='1,2,4', help='1-based station indices')

    ap.add_argument('--alpha', type=float, default=0.05)

    ap.add_argument('--hac-lags', type=int, default=HAC_LAGS,
                    help='Bartlett lag truncation; default floor(T_train**0.25)')

    ap.add_argument('--bias-bandwidth-factor', type=float, default=1.5)

    ap.add_argument('--refit', action='store_true')

    ap.add_argument('--max-iter', type=int, default=300)

    ap.add_argument('--tol', type=float, default=1e-6)

    ap.add_argument('--min-effective', type=float, default=2.0)

    args = ap.parse_args()



    h = float(MANUAL_H_PROPOSED)

    if not np.isfinite(h) or h <= 0:

        raise ValueError("MANUAL_H_PROPOSED must be a finite positive number")

    h_source = "MANUAL_H_PROPOSED in this CI script"
    if not 0 < args.alpha < 1:
        raise ValueError("alpha must be between 0 and 1")
    if args.bias_bandwidth_factor <= 0:
        raise ValueError("bias-bandwidth-factor must be positive")
    if args.hac_lags is not None and args.hac_lags < 0:
        raise ValueError("hac-lags must be nonnegative")
    # Normal critical value for the requested two-sided confidence level.
    zcrit = NormalDist().inv_cdf(1.0 - args.alpha / 2.0)
    level = 100.0 * (1.0 - args.alpha)





    # Same final design as 04. Test 2008 is NOT used for inference.

    df = load_and_prepare(ROOT / 'data' / 'uk16_with_AF.csv')

    d = fold_preprocess(df, 2007, 2008, x_cols=('sun','rain'))

    y, x, z = d['y_train'], d['x_train'], d['z_train']
    if args.hac_lags is None:
        args.hac_lags = int(np.floor(y.shape[1] ** 0.25))
    if args.hac_lags >= y.shape[1]:
        raise ValueError("hac-lags must be less than T_train")

    stations = d['stations']

    selected = parse_station_indices(args.station_idx, len(stations))



    fit, ys, xs, zs = load_or_refit_proposed(

        y, x, z, h, refit=args.refit, max_iter=args.max_iter, tol=args.tol

    )

    beta = np.asarray(fit['beta'], float)

    theta = np.asarray(fit['theta'], float)



    # IMPORTANT MODEL IDENTITIES:

    # index u_it          = theta_hat' X_it

    # partial response   = Y_it - beta_hat' Z_it

    # fitted partial     = g_hat_i(u_it)

    # model residual     = partial response - fitted partial

    # There is NO subtraction of theta_hat'X_it from Y unless g(u)=u is imposed.

    u_all = np.einsum('ntp,p->nt', xs, theta)

    partial_std = ys - np.einsum('ntd,d->nt', zs, beta)



    set_epan()

    gobs_std, slope_std, effective_rmave = r2.local_links(u_all, partial_std, h)



    y_mean = float(fit['scale']['y_mean'])

    y_sd = float(fit['scale']['y_sd'])



    outdir = ROOT / 'results' / 'proposed_inference_HAC'

    outdir.mkdir(parents=True, exist_ok=True)



    rows = []

    summary_rows = []



    for k, i in enumerate(selected):

        inf = infer_at_observed_points(

            u_all[i], partial_std[i], gobs_std[i], h,

            bias_bandwidth_factor=args.bias_bandwidth_factor,
            hac_lags=args.hac_lags
        )

        se_g_std = inf['se_hac']

        center_std = gobs_std[i] - inf['bias']



        ci_lo_std = center_std - zcrit*se_g_std

        ci_hi_std = center_std + zcrit*se_g_std



        # Prediction interval for a NEW partial response at the same index.

        # This is NOT the confidence interval for g_i(u).

        pred_se_std = np.sqrt(np.maximum(inf['prediction_variance_next_month'], 0.0))

        pi_lo_std = center_std - zcrit*pred_se_std

        pi_hi_std = center_std + zcrit*pred_se_std



        # Back to the adjusted TMAX scale used in the empirical application.

        partial = y_mean + y_sd*partial_std[i]

        ghat = y_mean + y_sd*gobs_std[i]

        center = y_mean + y_sd*center_std

        ci_lo = y_mean + y_sd*ci_lo_std

        ci_hi = y_mean + y_sd*ci_hi_std

        pi_lo = y_mean + y_sd*pi_lo_std

        pi_hi = y_mean + y_sd*pi_hi_std

        model_resid = y_sd*inf['resid']

        se_g = y_sd*se_g_std

        pred_se = y_sd*pred_se_std
        variance_g = y_sd**2 * inf['vhat_hac']
        variance_iid_theorem = y_sd**2 * inf['vhat_iid_theorem']
        variance_iid_local = y_sd**2 * inf['vhat_iid_local']
        bias_original = y_sd * inf['bias']
        g2_original = y_sd * inf['g2']



        order = np.argsort(u_all[i])

        us = u_all[i][order]

        gs = ghat[order]

        cil = ci_lo[order]; cih = ci_hi[order]
        center_sorted = center[order]

        pil = pi_lo[order]; pih = pi_hi[order]

        eff = inf['effective_n'][order]

        valid = np.isfinite(center_sorted) & np.isfinite(cil) & np.isfinite(cih) & (eff >= args.min_effective)

        valid_pi = valid & np.isfinite(pil) & np.isfinite(pih)



        # Figure 1: manuscript/reviewer target -- CI for the mean link only.
        fig_ci, a = plt.subplots(1, 1, figsize=(8.2, 3.75))
        a.scatter(u_all[i], partial, s=15, c='red', alpha=0.72, edgecolors='none')

        # Raw local-linear link: grey dotted curve, before bias correction.
        a.plot(us[valid], gs[valid], color='0.5', ls=':', lw=1.2)

        # Bias-corrected link: black solid curve.
        a.plot(us[valid], center_sorted[valid], 'k-', lw=1.25)

        a.plot(us[valid], cil[valid], color='black', ls='-.', lw=1.05)

        a.plot(us[valid], cih[valid], color='black', ls='-.', lw=1.05)


        fig_ci.tight_layout()

        # Figure 2: diagnostic -- adds prediction interval for observations.
        fig_pi, b = plt.subplots(1, 1, figsize=(8.2, 3.75))
        b.scatter(u_all[i], partial, s=15, c='red', alpha=0.72, edgecolors='none')

        # Raw local-linear link: grey dotted curve, before bias correction.
        b.plot(us[valid], gs[valid], color='0.5', ls=':', lw=1.2)

        # Bias-corrected link: black solid curve.
        b.plot(us[valid], center_sorted[valid], 'k-', lw=1.25)

        b.plot(us[valid], cil[valid], color='black', ls='-.', lw=1.0)

        b.plot(us[valid], cih[valid], color='black', ls='-.', lw=1.0)

        b.plot(us[valid_pi], pil[valid_pi], color='0.45', ls='--', lw=1.05)

        b.plot(us[valid_pi], pih[valid_pi], color='0.45', ls='--', lw=1.05)


        fig_pi.tight_layout()



        # Observation containment is a diagnostic, not a CI coverage target.
        valid_obs = (
            np.isfinite(ci_lo)
            & np.isfinite(ci_hi)
            & (inf['effective_n'] >= args.min_effective)
        )
        valid_pi_obs = (
            valid_obs
            & np.isfinite(pi_lo)
            & np.isfinite(pi_hi)
        )
        in_ci = (
            valid_obs
            & (partial >= ci_lo)
            & (partial <= ci_hi)
        )
        in_pi = (
            valid_pi_obs
            & (partial >= pi_lo)
            & (partial <= pi_hi)
        )
        mean_ci_width = (
            float(np.mean((ci_hi - ci_lo)[valid_obs]))
            if np.any(valid_obs) else np.nan
        )
        mean_pi_width = (
            float(np.mean((pi_hi - pi_lo)[valid_pi_obs]))
            if np.any(valid_pi_obs) else np.nan
        )

        summary = {
            'station_index': i + 1,
            'station': stations[i],
            'T_train': len(partial),
            'h': h,
            'bias_pilot_h': inf['pilot_h'],
            'hac_lags': args.hac_lags,
            'sigma_hat': y_sd * math.sqrt(max(inf['sigma2'], 0.0)),
            'sigma2_hat': y_sd ** 2 * inf['sigma2'],
            'mean_link_CI_width': mean_ci_width,
            'mean_prediction_interval_width': mean_pi_width,
            'n_valid_link_CI_points': int(np.sum(valid_obs)),
            'fraction_observed_inside_link_CI_NOT_COVERAGE': (
                float(np.sum(in_ci) / np.sum(valid_obs))
                if np.any(valid_obs) else np.nan
            ),
            'fraction_observed_inside_prediction_interval_NOT_COVERAGE': (
                float(np.sum(in_pi) / np.sum(valid_pi_obs))
                if np.any(valid_pi_obs) else np.nan
            ),
        }
        summary.update({
            f'error_autocov_lag{lag}_standardized': float(inf['gamma'][lag])
            for lag in range(len(inf['gamma']))
        })
        summary_rows.append(summary)



        point_data = {

            'station_index': i+1,

            'station': stations[i],

            'time_order': np.arange(1, len(partial)+1),

            'u_thetaX': u_all[i],

            'partial_response_Y_minus_betaZ': partial,

            'g_hat_raw': ghat,
            'g_second_derivative_hat': g2_original,
            'bias_hat': bias_original,
            'g_hat_bias_corrected': center,

            'model_residual_Y_minus_betaZ_minus_g': model_resid,
            'sigma2_hat': np.full(len(partial), y_sd**2 * inf['sigma2']),
            'variance_link': variance_g,
            'variance_link_IID_theorem': variance_iid_theorem,
            'variance_link_IID_exact_weights': variance_iid_local,
            'hac_lags': np.full(len(partial), args.hac_lags),
            'residual_gamma0_standardized': np.full(len(partial), inf['gamma'][0]),
            'covariance_future_error_and_link': (
                y_sd**2 * inf['covariance_next_error_and_link_estimate']
            ),
            'se_link': se_g,

            'ci_link_lower': ci_lo,

            'ci_link_upper': ci_hi,

            'prediction_se_partial_response': pred_se,
            'prediction_variance_next_month': (
                y_sd**2 * inf['prediction_variance_next_month']
            ),
            'prediction_lower': pi_lo,

            'prediction_upper': pi_hi,

            'f_hat': inf['fhat'],

            'effective_n': inf['effective_n'],

            'effective_n_rmave': effective_rmave[i],
            'valid_link_CI': (
                np.isfinite(ci_lo) & np.isfinite(ci_hi)
                & (inf['effective_n'] >= args.min_effective)
            ),
            'h': h,
        }
        for lag in range(1, len(inf['gamma'])):
            point_data[f'residual_gamma{lag}_standardized'] = np.full(
                len(partial), inf['gamma'][lag]
            )
        rows.append(pd.DataFrame(point_data))

        
        suffix = f"biascorrected_BartlettHAC_L{args.hac_lags}_h{h:g}"
        f_ci = outdir / f'UK_proposed_link_95CI_{suffix}_station_{i+1}.png'
        f_pi = outdir / f'UK_proposed_link_95CI_plus_prediction_interval_{suffix}_station_{i+1}.png'

        fig_ci.savefig(f_ci, dpi=240, bbox_inches='tight')
        fig_pi.savefig(f_pi, dpi=240, bbox_inches='tight')
        plt.close(fig_ci); plt.close(fig_pi)



    suffix = f"biascorrected_BartlettHAC_L{args.hac_lags}_h{h:g}"

    f_csv = outdir / f'UK_proposed_inference_points_{suffix}.csv'

    f_sum = outdir / f'UK_proposed_inference_summary_{suffix}.csv'

    f_meta = outdir / f'UK_proposed_inference_metadata_{suffix}.csv'



    pd.concat(rows, ignore_index=True).to_csv(f_csv, index=False)

    pd.DataFrame(summary_rows).to_csv(f_sum, index=False)

    pd.DataFrame([{

        'train_period': '1999-01--2007-12',

        'test_period_excluded_from_inference': '2008-01--2008-12',

        'model': 'Y_it = g_i(theta^T X_it) + beta^T Z_it + e_it',

        'x_axis': 'theta_hat^T X_it',

        'red_points': 'Y_it - beta_hat^T Z_it',

        'fitted_residual': 'Y_it - beta_hat^T Z_it - g_hat_i(theta_hat^T X_it)',

        'explicitly_NOT_used': 'Y_it - theta_hat^T X_it - beta_hat^T Z_it',

        'h_proposed': h,

        'h_source': h_source,

        'kernel': 'Epanechnikov',

        'link_interval': 'Bias-corrected pointwise confidence interval for g_i(u)',

        'prediction_interval': 'Approximate one-month-ahead prediction interval for a new partial response Y-betaZ',

        'variance_formula': 'Bartlett HAC of exact local-linear intercept weights and residual autocovariances',
        'variance_IID_comparison_formula': 'sigma2_hat*R(K)/(T*h*f_hat)',
        'hac_lags': args.hac_lags,
        'hac_autocovariance_denominator': 'T',
        'hac_bandwidth_weight': 'Bartlett 1-lag/(L+1)',
        'future_prediction_horizon': 'one month after training',
        'ci_standard_error': 'Local-linear-weighted, within-station Bartlett HAC',
        'beta_theta_uncertainty': 'Treated as fixed; not included in link-function HAC variance',

        'bias_corrected': True,

        'alpha': args.alpha,
        'critical_value': zcrit,
        'simultaneous_confidence_band': False,

        'mu2_K': epan_constants()[0],

        'R_K': epan_constants()[1],

        'theta_beta_source': '04 saved estimates' if fit.get('loaded_from_04') else 'refit Proposed',

        'leading_bias': '0.5 * mu2(K) * h^2 * g2_hat(u)',
        'g2_estimator': 'local quadratic, pilot bandwidth = bias_bandwidth_factor * h',
        'extra_smoothing': 'none; no LOWESS/spline',

    }]).to_csv(f_meta, index=False)



    print('\nCompleted UK Proposed link inference.')
    print(f'Main bandwidth h = {h}')
    print(f'Local quadratic pilot bandwidth = {h * args.bias_bandwidth_factor}')
    print(f'Confidence level = {level:g}%')
    print(f'Bartlett HAC lags = {args.hac_lags}')
    print('CI variance = Bartlett HAC covariance of local-linear intercept weights')
    print('IID Theorem 4.3 variance is also saved for comparison.')
    print('Prediction interval is approximate, for one month after training.')

    print('Red dots are Y - beta_hat^T Z; NOT Y - theta_hat^T X - beta_hat^T Z.')

    print('The link CI is pointwise, not simultaneous, and is not intended to contain 95% of individual observations.')

    print(f'CI figure directory: {outdir}')
    print(f'Pointwise values: {f_csv}')

    print(f'Summary: {f_sum}')





if __name__ == '__main__':

    main()

