from __future__ import annotations
import numpy as np
import pandas as pd

STATIONS_EXPECTED = 16
MONTH_DUMMIES = [f"M{m:02d}" for m in range(1, 12)]
CONTINUOUS = ["tmax", "sun", "rain", "AF"]


def load_and_prepare(path):
    df = pd.read_csv(path)
    need = {"station","year","month","tmax","sun","rain","AF"}
    miss = need.difference(df.columns)
    if miss:
        raise ValueError(f"Missing columns: {sorted(miss)}")
    df = df.sort_values(["station","year","month"]).reset_index(drop=True)
    if df[list(need)].isna().any().any():
        raise ValueError("Missing values detected in required variables")
    if df["station"].nunique() != STATIONS_EXPECTED:
        raise ValueError(f"Expected 16 stations; found {df['station'].nunique()}")
    counts = df.groupby("station").size()
    if counts.nunique()!=1 or counts.iloc[0] != 120:
        raise ValueError(f"Expected balanced 16 x 120 panel; counts={counts.to_dict()}")
    for m in range(1,12):
        df[f"M{m:02d}"] = (df["month"]==m).astype(float)
    return df


def export_model_ready(raw_path, out_path):
    df = load_and_prepare(raw_path)
    cols = ["station","year","month","tmax","sun","rain","AF"] + MONTH_DUMMIES
    df[cols].to_csv(out_path, index=False)
    return df[cols]


def _fit_linear_trend(train_station, col):
    # Absolute month index keeps a common time origin across folds.
    t = ((train_station["year"].to_numpy()-1999)*12 + (train_station["month"].to_numpy()-1)).astype(float)
    X = np.column_stack([np.ones(len(t)), t])
    coef = np.linalg.pinv(X) @ train_station[col].to_numpy(float)
    return coef


def _apply_linear_trend(frame_station, col, coef):
    t = ((frame_station["year"].to_numpy()-1999)*12 + (frame_station["month"].to_numpy()-1)).astype(float)
    return frame_station[col].to_numpy(float) - (coef[0] + coef[1]*t)


def fold_preprocess(df, train_end_year, eval_year=None, x_cols=("sun","rain")):
    """Fit station-specific intercept+linear trend on training years only.

    Month dummies are never residualized. If eval_year is None, only training
    arrays are returned. All arrays are N x T x p (or N x T for y) and stations
    are kept in sorted order.
    """
    train = df[df.year <= train_end_year].copy()
    eva = None if eval_year is None else df[df.year == eval_year].copy()
    stations = sorted(df.station.unique())
    y_train=[]; x_train=[]; z_train=[]; y_eval=[]; x_eval=[]; z_eval=[]
    for st in stations:
        tr=train[train.station==st].sort_values(["year","month"]).copy()
        ev=None if eva is None else eva[eva.station==st].sort_values(["year","month"]).copy()
        trends={c:_fit_linear_trend(tr,c) for c in set(["tmax",*x_cols])}
        y_train.append(_apply_linear_trend(tr,"tmax",trends["tmax"]))
        x_train.append(np.column_stack([_apply_linear_trend(tr,c,trends[c]) for c in x_cols]))
        z_train.append(tr[MONTH_DUMMIES].to_numpy(float))
        if ev is not None:
            y_eval.append(_apply_linear_trend(ev,"tmax",trends["tmax"]))
            x_eval.append(np.column_stack([_apply_linear_trend(ev,c,trends[c]) for c in x_cols]))
            z_eval.append(ev[MONTH_DUMMIES].to_numpy(float))
    out={
        "stations":stations,
        "y_train":np.stack(y_train),
        "x_train":np.stack(x_train),
        "z_train":np.stack(z_train),
    }
    if eva is not None:
        out.update({"y_eval":np.stack(y_eval),"x_eval":np.stack(x_eval),"z_eval":np.stack(z_eval)})
    return out


def metrics(y, pred):
    y=np.asarray(y,float); pred=np.asarray(pred,float)
    mse=float(np.mean((y-pred)**2))
    sse=float(np.sum((y-pred)**2))
    sst=float(np.sum((y-y.mean())**2))
    r2=float(1-sse/sst)
    return {"MSE":mse,"RMSE":float(np.sqrt(mse)),"R2":r2}


def folds():
    return [(2003,2004),(2004,2005),(2005,2006),(2006,2007)]
