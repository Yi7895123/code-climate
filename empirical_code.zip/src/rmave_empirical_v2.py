"""Leakage-controlled empirical RMAVE analysis for the revision.

The implementation follows equations (local-link) and (param-update) in the
manuscript.  In particular, the Gaussian kernel is defined once as phi(u) and
K_h(v)=phi(v/h)/h; kernel weights are recomputed after every theta update.
All preprocessing and model choices are fitted inside chronological training
blocks, and predictions are evaluated on later dates.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
EPS = 1.0e-12
KERNEL_NAME = "gaussian"
SQRT_2PI = float(np.sqrt(2.0 * np.pi))


def gaussian_kernel(u):
    """Standard Gaussian density phi(u), with no bandwidth embedded in it."""
    u = np.asarray(u, dtype=float)
    return np.exp(-0.5 * u * u) / SQRT_2PI


def set_kernel(name):
    """Set the process-local kernel used by RMAVE fits and predictions."""
    global KERNEL_NAME
    if name not in {"gaussian", "epanechnikov"}:
        raise ValueError(f"unknown kernel: {name}")
    KERNEL_NAME = name


def kernel_h(delta, h):
    """Return K(delta/h)/h with the bandwidth applied exactly once."""
    if h <= 0:
        raise ValueError("bandwidth h must be positive")
    u = np.asarray(delta, dtype=float) / h
    if KERNEL_NAME == "gaussian":
        values = gaussian_kernel(u)
    else:
        values = 0.75 * np.maximum(1.0 - u * u, 0.0) * (np.abs(u) <= 1.0)
    return values / h


def normalize_theta(theta):
    theta = np.asarray(theta, dtype=float).reshape(-1)
    length = float(np.linalg.norm(theta))
    if length <= EPS:
        theta = np.zeros_like(theta)
        theta[0] = 1.0
    else:
        theta = theta / length
    nonzero = np.flatnonzero(np.abs(theta) > 1.0e-10)
    if nonzero.size and theta[nonzero[0]] < 0:
        theta = -theta
    return theta


def scale_train(y, x, z):
    def stats(v):
        if v.shape[2] == 0:
            return np.empty(0), np.empty(0)
        flat = v.reshape(-1, v.shape[2])
        mean = flat.mean(axis=0)
        sd = flat.std(axis=0)
        return mean, np.where(sd > EPS, sd, 1.0)

    y_mean, y_sd = float(y.mean()), float(y.std() or 1.0)
    x_mean, x_sd = stats(x)
    z_mean, z_sd = stats(z)
    scale = {"y_mean": y_mean, "y_sd": y_sd, "x_mean": x_mean,
             "x_sd": x_sd, "z_mean": z_mean, "z_sd": z_sd}
    return apply_scale(y, x, z, scale), scale


def apply_scale(y, x, z, scale):
    ys = (np.asarray(y, float) - scale["y_mean"]) / scale["y_sd"]
    xs = ((np.asarray(x, float) - scale["x_mean"]) / scale["x_sd"]
          if x.shape[2] else np.asarray(x, float).copy())
    zs = ((np.asarray(z, float) - scale["z_mean"]) / scale["z_sd"]
          if z.shape[2] else np.asarray(z, float).copy())
    return ys, xs, zs


def within_ols_initial(y, x, z):
    n, t = y.shape
    d, p = z.shape[2], x.shape[2]
    yd = y - y.mean(axis=1, keepdims=True)
    xd = x - x.mean(axis=1, keepdims=True)
    zd = z - z.mean(axis=1, keepdims=True) if d else z
    design = np.concatenate([zd, xd], axis=2).reshape(n * t, d + p)
    coef = np.linalg.pinv(design) @ yd.reshape(-1)
    return coef[:d].copy(), normalize_theta(coef[d:])


def z_only_initial(y, z):
    n, t = y.shape
    d = z.shape[2]
    if d == 0:
        return np.empty(0)
    yd = y - y.mean(axis=1, keepdims=True)
    zd = z - z.mean(axis=1, keepdims=True)
    return np.linalg.pinv(zd.reshape(n * t, d)) @ yd.reshape(-1)


def polynomial_opg_initial(y, x, z):
    """A deterministic OPG warm start using unitwise quadratic regressions."""
    beta, fallback = within_ols_initial(y, x, z)
    p = x.shape[2]
    residual = y - np.einsum("ntd,d->nt", z, beta) if z.shape[2] else y.copy()
    opg = np.zeros((p, p))
    for i in range(y.shape[0]):
        xi = x[i]
        columns = [np.ones(xi.shape[0])]
        columns.extend(xi[:, j] for j in range(p))
        pairs = list(itertools.combinations_with_replacement(range(p), 2))
        columns.extend(xi[:, j] * xi[:, k] for j, k in pairs)
        coef = np.linalg.pinv(np.column_stack(columns)) @ residual[i]
        grad = np.broadcast_to(coef[1:1 + p], xi.shape).copy()
        for value, (j, k) in zip(coef[1 + p:], pairs):
            if j == k:
                grad[:, j] += 2.0 * value * xi[:, j]
            else:
                grad[:, j] += value * xi[:, k]
                grad[:, k] += value * xi[:, j]
        opg += grad.T @ grad
    values, vectors = np.linalg.eigh(opg)
    theta = vectors[:, int(np.argmax(values))]
    if not np.isfinite(theta).all() or float(np.linalg.norm(theta)) <= EPS:
        theta = fallback
    return beta, normalize_theta(theta)


def initial_candidates(y, x, z, full=True, seed=20260808):
    p = x.shape[2]
    candidates = []
    beta_fe, theta_fe = within_ols_initial(y, x, z)
    beta_opg, theta_opg = polynomial_opg_initial(y, x, z)
    candidates.extend([("opg", beta_opg, theta_opg),
                       ("within_fe", beta_fe, theta_fe)])
    if full and p > 1:
        beta_z = z_only_initial(y, z)
        candidates.append(("equal", beta_z.copy(), normalize_theta(np.ones(p))))
        rng = np.random.default_rng(seed)
        for j in range(3):
            candidates.append((f"sphere_{j + 1}", beta_z.copy(),
                               normalize_theta(rng.normal(size=p))))
    unique = []
    for name, beta, theta in candidates:
        if not any(np.linalg.norm(theta - item[2]) < 1.0e-8 for item in unique):
            unique.append((name, np.asarray(beta, float), np.asarray(theta, float)))
    return unique


def local_links(u, residual, h):
    """All unit-specific local-linear coefficients at observed index values."""
    n, t = u.shape
    a, b = np.zeros((n, t)), np.zeros((n, t))
    effective = np.zeros((n, t))
    for i in range(n):
        delta = u[i, :, None] - u[i, None, :]
        weights = kernel_h(delta, h)
        s0 = weights.sum(axis=0)
        s1 = (weights * delta).sum(axis=0)
        s2 = (weights * delta * delta).sum(axis=0)
        if KERNEL_NAME == 'epanechnikov' and np.any(s0 * s2 - s1 * s1 <= EPS * np.maximum(s0 * s0, 1.0)):
            raise ValueError('individual-link compact local slope is not identifiable')
        r0 = (weights * residual[i, :, None]).sum(axis=0)
        r1 = (weights * delta * residual[i, :, None]).sum(axis=0)
        ridge = 1.0e-10 * np.maximum(s0 + s2, 1.0)
        aa, cc = s0 + ridge, s2 + ridge
        det = np.maximum(aa * cc - s1 * s1, EPS)
        a[i] = (cc * r0 - s1 * r1) / det
        b[i] = (aa * r1 - s1 * r0) / det
        effective[i] = s0 * s0 / np.maximum((weights * weights).sum(axis=0), EPS)
    return a, b, effective


def rmave_objective(y, x, z, beta, theta, a, b, h):
    total, weight_total = 0.0, 0.0
    for i in range(y.shape[0]):
        u = x[i] @ theta
        delta = u[:, None] - u[None, :]
        weights = kernel_h(delta, h)
        density = np.maximum(weights.mean(axis=0), EPS)
        fitted = a[i][None, :] + b[i][None, :] * delta
        if z.shape[2]:
            fitted = fitted + (z[i] @ beta)[:, None]
        scaled = weights / density[None, :]
        total += float(np.sum(scaled * (y[i, :, None] - fitted) ** 2))
        weight_total += float(np.sum(scaled))
    return total / max(weight_total, EPS)


def fit_rmave(y, x, z, h, init, max_iter=40, tol=1.0e-6):
    """Fit the manuscript RMAVE update on already standardized arrays."""
    n, t, p = x.shape
    d = z.shape[2]
    beta, theta = np.asarray(init[0], float).copy(), normalize_theta(init[1])
    delta_param = float("inf")
    for iteration in range(1, max_iter + 1):
        old = np.concatenate([beta, theta])
        u = np.einsum("ntp,p->nt", x, theta)
        residual = y - np.einsum("ntd,d->nt", z, beta) if d else y.copy()
        a, b, effective = local_links(u, residual, h)
        lhs = np.zeros((d + p, d + p))
        rhs = np.zeros(d + p)
        for i in range(n):
            du = u[i, :, None] - u[i, None, :]
            weights = kernel_h(du, h)
            density = np.maximum(weights.mean(axis=0), EPS)
            dx = x[i, :, None, :] - x[i, None, :, :]
            zrep = (np.broadcast_to(z[i, :, None, :], (t, t, d))
                    if d else np.empty((t, t, 0)))
            design = np.concatenate([zrep, b[i][None, :, None] * dx], axis=2)
            scaled = weights / density[None, :]
            target = y[i, :, None] - a[i, None, :]
            lhs += np.einsum("ts,tsq,tsr->qr", scaled, design, design)
            rhs += np.einsum("ts,tsq,ts->q", scaled, design, target)
        update = np.linalg.pinv(lhs) @ rhs
        beta, theta = update[:d], normalize_theta(update[d:])
        delta_param = float(np.linalg.norm(np.concatenate([beta, theta]) - old))
        if delta_param < tol:
            break
    u = np.einsum("ntp,p->nt", x, theta)
    residual = y - np.einsum("ntd,d->nt", z, beta) if d else y.copy()
    a, b, effective = local_links(u, residual, h)
    return {"beta": beta, "theta": theta, "u": u, "residual": residual,
            "a": a, "b": b, "effective_train": effective, "h": float(h),
            "iterations": int(iteration), "terminal_delta": delta_param,
            "converged": bool(delta_param < tol),
            "objective": rmave_objective(y, x, z, beta, theta, a, b, h)}


def fit_scaled_multistart(y, x, z, h, full_starts=True, max_iter=40, tol=1.0e-6):
    (ys, xs, zs), scale = scale_train(y, x, z)
    fits = []
    failures = []
    for name, beta, theta in initial_candidates(ys, xs, zs, full=full_starts):
        try:
            fit = fit_rmave(ys, xs, zs, h, (beta, theta), max_iter=max_iter, tol=tol)
        except (ValueError, FloatingPointError, np.linalg.LinAlgError) as exc:
            failures.append({'start': name, 'failure': str(exc), 'converged': False,
                             'initial_beta': beta.tolist(), 'initial_theta': theta.tolist()})
            continue
        fit['initial_beta'], fit['initial_theta'] = beta.tolist(), theta.tolist()
        fits.append((name, fit))
    if not fits:
        raise ValueError('all starts failed: ' + str(failures))
    converged = [item for item in fits if item[1]["converged"]]
    selected_name, selected = min(
        converged or fits, key=lambda item: item[1]["objective"])
    selected.update({"scale": scale, "selected_start": selected_name,
                     "start_diagnostics": [
                         {"start": name, "objective": float(fit["objective"]),
                          "iterations": int(fit["iterations"]),
                          "terminal_delta": float(fit["terminal_delta"]),
                          "converged": bool(fit["converged"]),
                          "beta": fit["beta"].tolist(), "theta": fit["theta"].tolist(),
                          "initial_beta": fit['initial_beta'], "initial_theta": fit['initial_theta']}
                         for name, fit in fits] + failures})
    return selected


def profiled_fe_moments(weights, design, target, n, t):
    """Weighted cross-products after profiling Chen et al. (2013a) fixed effects.

    The implicit dummy matrix uses unit 1 as ``-1`` in every contrast and
    units 2,...,N as the corresponding identity row, imposing sum(alpha)=0.
    This is algebraically the same projection used by the supplied PLSI.m,
    without constructing an (NT)-by-(N-1) matrix for every local fit.
    """
    weights = np.asarray(weights, float).reshape(n * t)
    total = float(weights.sum())
    if total <= EPS:
        weights = np.full(n * t, 1.0 / (n * t))
    else:
        weights = weights / total
    design = np.asarray(design, float).reshape(n * t, -1)
    target = np.asarray(target, float).reshape(n * t)
    raw_lhs = design.T @ (weights[:, None] * design)
    raw_rhs = design.T @ (weights * target)
    if n == 1:
        return raw_lhs, raw_rhs

    unit_weights = weights.reshape(n, t)
    sums = unit_weights.sum(axis=1)
    weighted_design = np.einsum(
        "nt,ntq->nq", unit_weights, design.reshape(n, t, -1))
    weighted_target = np.einsum("nt,nt->n", unit_weights, target.reshape(n, t))
    dummy_lhs = np.diag(sums[1:]) + sums[0] * np.ones((n - 1, n - 1))
    dummy_design = weighted_design[1:] - weighted_design[0]
    dummy_target = weighted_target[1:] - weighted_target[0]
    dummy_inverse = np.linalg.pinv(dummy_lhs, rcond=1.0e-8)
    lhs = raw_lhs - dummy_design.T @ dummy_inverse @ dummy_design
    rhs = raw_rhs - dummy_design.T @ dummy_inverse @ dummy_target
    return lhs, rhs


def common_fe_local_links(y, x, z, beta, theta, h, evaluation_u=None):
    """Pooled local links with the Chen et al. (2013a) dummy projection."""
    n, t, _ = x.shape
    m = n * t
    xf = x.reshape(m, -1)
    zf = z.reshape(m, -1)
    yf = y.reshape(m)
    u = xf @ theta
    centers = u if evaluation_u is None else np.asarray(evaluation_u).reshape(-1)
    c = len(centers)
    residual = yf - zf @ beta if z.shape[2] else yf.copy()
    delta = u[:, None] - centers[None, :]
    weights = kernel_h(delta, h)
    if np.any(weights.sum(axis=0) <= EPS):
        raise ValueError('common-link evaluation has no kernel support')
    weights /= np.maximum(weights.sum(axis=0, keepdims=True), EPS)
    unit_weights = weights.reshape(n, t, c)
    unit_sums = unit_weights.sum(axis=1)

    if KERNEL_NAME == 'epanechnikov':
        # With sum-to-zero dummy contrasts, the common local intercept needs
        # support from every unit; a pseudoinverse cannot identify absent units.
        if np.any(unit_sums <= EPS):
            raise ValueError('common-link compact kernel lacks support for every unit')
        unit_mean = np.einsum('ntc,nt->nc', unit_weights, u.reshape(n, t)) / unit_sums
        within_variation = np.sum(
            unit_weights * (u.reshape(n, t, 1)-unit_mean[:, None, :])**2,
            axis=(0, 1))
        if np.any(within_variation <= EPS):
            raise ValueError('common-link compact local slope is not identifiable')

    if n > 1:
        dummy_lhs = np.zeros((c, n - 1, n - 1))
        diagonal = np.arange(n - 1)
        dummy_lhs[:, diagonal, diagonal] = unit_sums[1:].T
        dummy_lhs += unit_sums[0, :, None, None]
        dummy_inverse = np.linalg.pinv(dummy_lhs, rcond=1.0e-8)
    else:
        dummy_inverse = np.empty((c, 0, 0))

    s1 = np.sum(weights * delta, axis=0)
    s2 = np.sum(weights * delta * delta, axis=0)
    r0 = weights.T @ residual
    r1 = np.sum(weights * delta * residual[:, None], axis=0)
    local_lhs = np.zeros((c, 2, 2))
    local_lhs[:, 0, 0] = 1.0
    local_lhs[:, 0, 1] = s1
    local_lhs[:, 1, 0] = s1
    local_lhs[:, 1, 1] = s2
    local_rhs = np.column_stack([r0, r1])

    if n > 1:
        unit_u = np.einsum("ntc,nt->nc", unit_weights, u.reshape(n, t))
        unit_delta = unit_u - unit_sums * centers[None, :]
        unit_residual = np.einsum(
            "ntc,nt->nc", unit_weights, residual.reshape(n, t))
        dummy_local = np.stack(
            [unit_sums[1:] - unit_sums[0],
             unit_delta[1:] - unit_delta[0]], axis=2).transpose(1, 0, 2)
        dummy_residual = (unit_residual[1:] - unit_residual[0]).T
        local_lhs -= np.einsum(
            "ckq,ckl,clr->cqr", dummy_local, dummy_inverse, dummy_local,
            optimize=True)
        local_rhs -= np.einsum(
            "ckq,ckl,cl->cq", dummy_local, dummy_inverse, dummy_residual,
            optimize=True)
    local_lhs = 0.5 * (local_lhs + local_lhs.transpose(0, 2, 1))
    local_ridge = 1.0e-10 * np.maximum(
        np.trace(local_lhs, axis1=1, axis2=2), 1.0)
    local_lhs[:, np.arange(2), np.arange(2)] += local_ridge[:, None]
    coefficient = np.einsum(
        "cqr,cr->cq", np.linalg.pinv(local_lhs, rcond=1.0e-10), local_rhs,
        optimize=True)
    return u, coefficient[:, 0], coefficient[:, 1], weights, dummy_inverse


def fit_common_fe_smave(y, x, z, h, init, max_iter=40, tol=1.0e-6):
    """Chen et al. (2013a) common-link PLSI with profiled unit effects."""
    n, t, p = x.shape
    d = z.shape[2]
    m = n * t
    xf = x.reshape(m, p)
    zf = z.reshape(m, d)
    yf = y.reshape(m)
    beta, theta = np.asarray(init[0], float).copy(), normalize_theta(init[1])
    delta_param = float("inf")
    for iteration in range(1, max_iter + 1):
        old = np.concatenate([beta, theta])
        u, a, b, weights, dummy_inverse = common_fe_local_links(
            y, x, z, beta, theta, h)
        dx = xf[:, None, :] - xf[None, :, :]
        design = np.empty((m, m, d + p))
        if d:
            design[:, :, :d] = zf[:, None, :]
        design[:, :, d:] = b[None, :, None] * dx
        target = yf[:, None] - a[None, :]
        center_lhs = np.einsum(
            "jc,jcq,jcr->cqr", weights, design, design, optimize=True)
        center_rhs = np.einsum(
            "jc,jcq,jc->cq", weights, design, target, optimize=True)
        if n > 1:
            unit_weights = weights.reshape(n, t, m)
            unit_design = np.einsum(
                "ntc,ntcq->ncq", unit_weights,
                design.reshape(n, t, m, d + p), optimize=True)
            unit_target = np.einsum(
                "ntc,ntc->nc", unit_weights, target.reshape(n, t, m),
                optimize=True)
            dummy_design = (unit_design[1:] - unit_design[0]).transpose(1, 0, 2)
            dummy_target = (unit_target[1:] - unit_target[0]).T
            center_lhs -= np.einsum(
                "ckq,ckl,clr->cqr", dummy_design, dummy_inverse,
                dummy_design, optimize=True)
            center_rhs -= np.einsum(
                "ckq,ckl,cl->cq", dummy_design, dummy_inverse,
                dummy_target, optimize=True)
        lhs = center_lhs.sum(axis=0)
        rhs = center_rhs.sum(axis=0)
        lhs = 0.5 * (lhs + lhs.T)
        ridge = 1.0e-10 * max(float(np.trace(lhs)) / max(d + p, 1), 1.0)
        lhs += ridge * np.eye(d + p)
        if not np.isfinite(lhs).all() or not np.isfinite(rhs).all():
            raise FloatingPointError("non-finite Chen-2013a profiled update")
        update = np.linalg.pinv(lhs, rcond=1.0e-10) @ rhs
        if not np.isfinite(update).all():
            raise FloatingPointError("non-finite Chen-2013a parameter update")
        beta, theta = update[:d], normalize_theta(update[d:])
        delta_param = float(np.linalg.norm(np.concatenate([beta, theta]) - old))
        if delta_param < tol:
            break

    u, a, b, _, _ = common_fe_local_links(y, x, z, beta, theta, h)
    partial = y - np.einsum("ntd,d->nt", z, beta) if d else y.copy()
    raw_alpha = (partial - a.reshape(n, t)).mean(axis=1)
    alpha_shift = float(raw_alpha.mean())
    alpha = raw_alpha - alpha_shift
    fitted = (np.einsum("ntd,d->nt", z, beta) if d else np.zeros_like(y))
    fitted += alpha[:, None] + a.reshape(n, t) + alpha_shift
    objective = float(np.mean((y - fitted) ** 2))
    link_response = partial - alpha[:, None]
    return {"beta": beta, "theta": theta, "u": u, "a": a, "b": b,
            "alpha": alpha, "link_response": link_response.reshape(m),
            "training_y": y, "training_x": x, "training_z": z,
            "link_shift": alpha_shift,
            "h": float(h), "iterations": int(iteration),
            "terminal_delta": delta_param, "converged": bool(delta_param < tol),
            "objective": objective}


def fit_common_scaled_multistart(y, x, z, h, full_starts=True,
                                 max_iter=40, tol=1.0e-6):
    (ys, xs, zs), scale = scale_train(y, x, z)
    fits = []
    failures = []
    for name, beta, theta in initial_candidates(ys, xs, zs, full=full_starts):
        try:
            fit = fit_common_fe_smave(
                ys, xs, zs, h, (beta, theta), max_iter=max_iter, tol=tol)
        except (ValueError, FloatingPointError, np.linalg.LinAlgError) as exc:
            failures.append({'start': name, 'failure': str(exc), 'converged': False,
                             'initial_beta': beta.tolist(), 'initial_theta': theta.tolist()})
            continue
        fit['initial_beta'], fit['initial_theta'] = beta.tolist(), theta.tolist()
        fits.append((name, fit))
    if not fits:
        raise ValueError('all starts failed: ' + str(failures))
    converged = [item for item in fits if item[1]["converged"]]
    selected_name, selected = min(
        converged or fits, key=lambda item: item[1]["objective"])
    selected.update({"scale": scale, "selected_start": selected_name,
                     "start_diagnostics": [
                         {"start": name, "objective": float(fit["objective"]),
                          "iterations": int(fit["iterations"]),
                          "terminal_delta": float(fit["terminal_delta"]),
                          "converged": bool(fit["converged"]),
                          "beta": fit["beta"].tolist(), "theta": fit["theta"].tolist(),
                          "initial_beta": fit['initial_beta'], "initial_theta": fit['initial_theta']}
                         for name, fit in fits] + failures})
    return selected


def fit_common_scaled_search(y, x, z, h, max_iter=30, tol=1.0e-5):
    """Cheap bandwidth-screening fit; the final benchmark still uses two starts."""
    (ys, xs, zs), scale = scale_train(y, x, z)
    beta, theta = within_ols_initial(ys, xs, zs)
    fit = fit_common_fe_smave(
        ys, xs, zs, h, (beta, theta), max_iter=max_iter, tol=tol)
    fit.update({"scale": scale, "selected_start": "within_fe",
                "start_diagnostics": [{
                    "start": "within_fe", "objective": float(fit["objective"]),
                    "iterations": int(fit["iterations"]),
                    "terminal_delta": float(fit["terminal_delta"]),
                    "converged": bool(fit["converged"]),
                    "beta": fit["beta"].tolist(), "theta": fit["theta"].tolist()}]})
    return fit


def predict_common_scaled(fit, x_new, z_new):
    """Predict for ALL training units in their original order, never new units."""
    if (x_new.ndim != 3 or z_new.ndim != 3
            or x_new.shape[:2] != z_new.shape[:2]
            or x_new.shape[0] != fit['training_y'].shape[0]
            or x_new.shape[2] != fit['training_x'].shape[2]
            or z_new.shape[2] != fit['training_z'].shape[2]):
        raise ValueError('prediction requires all training units in original order and matching feature dimensions')
    scale = fit["scale"]
    dummy_y = np.zeros(x_new.shape[:2])
    _, xs, zs = apply_scale(dummy_y, x_new, z_new, scale)
    u_new = np.einsum("ntp,p->nt", xs, fit["theta"])
    pred = np.zeros_like(u_new)
    for i in range(u_new.shape[0]):
        # Chen (2013a), Eq. (2.6), evaluated at the NEW index. The weighted
        # fixed-effect projection depends on this index and cannot be replaced
        # by ordinary smoothing of globally de-effected responses.
        _, a, _, _, _ = common_fe_local_links(
            fit['training_y'], fit['training_x'], fit['training_z'],
            fit['beta'], fit['theta'], fit['h'], evaluation_u=u_new[i])
        pred[i] = a + fit['link_shift'] + fit['alpha'][i]
        if zs.shape[2]:
            pred[i] += zs[i] @ fit["beta"]
    return scale["y_mean"] + scale["y_sd"] * pred


def predict_scaled(fit, x_new, z_new, return_diagnostics=False):
    scale = fit["scale"]
    dummy_y = np.zeros(x_new.shape[:2])
    _, xs, zs = apply_scale(dummy_y, x_new, z_new, scale)
    u_new = np.einsum("ntp,p->nt", xs, fit["theta"])
    pred = np.zeros(u_new.shape)
    effective = np.zeros(u_new.shape)
    outside = np.zeros(u_new.shape, dtype=bool)
    for i in range(u_new.shape[0]):
        delta = fit["u"][i, :, None] - u_new[i][None, :]
        weights = kernel_h(delta, fit["h"])
        s0 = weights.sum(axis=0)
        if KERNEL_NAME == 'epanechnikov' and np.any(s0 <= EPS):
            raise ValueError('individual-link prediction has no kernel support')
        s1 = (weights * delta).sum(axis=0)
        s2 = (weights * delta * delta).sum(axis=0)
        if KERNEL_NAME == 'epanechnikov' and np.any(s0 * s2 - s1 * s1 <= EPS * np.maximum(s0 * s0, 1.0)):
            raise ValueError('individual-link compact prediction slope is not identifiable')
        r0 = (weights * fit["residual"][i, :, None]).sum(axis=0)
        r1 = (weights * delta * fit["residual"][i, :, None]).sum(axis=0)
        ridge = 1.0e-10 * np.maximum(s0 + s2, 1.0)
        aa, cc = s0 + ridge, s2 + ridge
        det = np.maximum(aa * cc - s1 * s1, EPS)
        pred[i] = (cc * r0 - s1 * r1) / det
        if zs.shape[2]:
            pred[i] += zs[i] @ fit["beta"]
        effective[i] = s0 * s0 / np.maximum((weights * weights).sum(axis=0), EPS)
        outside[i] = (u_new[i] < fit["u"][i].min()) | (u_new[i] > fit["u"][i].max())
    pred = scale["y_mean"] + scale["y_sd"] * pred
    if return_diagnostics:
        return pred, {"effective_test": effective, "outside_support": outside}
    return pred


def fit_linear_fe(y, w):
    yd = y - y.mean(axis=1, keepdims=True)
    wd = w - w.mean(axis=1, keepdims=True)
    coef = np.linalg.pinv(wd.reshape(-1, w.shape[2])) @ yd.reshape(-1)
    alpha = (y - np.einsum("ntk,k->nt", w, coef)).mean(axis=1)
    return {"coef": coef, "alpha": alpha}


def predict_linear_fe(fit, w):
    return fit["alpha"][:, None] + np.einsum("ntk,k->nt", w, fit["coef"])


def date_design(dates, kind):
    dates = pd.DatetimeIndex(dates)
    if kind == "level":
        return None
    if kind == "station_mean":
        return np.ones((len(dates), 1))
    if not kind.startswith("seasonal"):
        raise ValueError(f"unknown preprocessing kind: {kind}")
    harmonics = int(kind.removeprefix("seasonal"))
    time = np.arange(len(dates), dtype=float) / max(len(dates) - 1, 1)
    monthly = bool(np.all(dates.day == 1) and len(pd.Index(dates.month).unique()) <= 12)
    phase = (2.0 * np.pi * (dates.month.to_numpy() - 1) / 12.0 if monthly
             else 2.0 * np.pi * (dates.dayofyear.to_numpy() - 1) / 365.25)
    columns = [np.ones(len(dates)), time]
    for j in range(1, harmonics + 1):
        columns.extend([np.sin(j * phase), np.cos(j * phase)])
    return np.column_stack(columns)


def preprocess_panel(y, w, dates, fit_end, kind):
    design = date_design(dates, kind)
    values = np.concatenate([y[:, :, None], w], axis=2)
    offset = np.zeros_like(values)
    if design is not None:
        for i in range(values.shape[0]):
            coef = np.linalg.pinv(design[:fit_end]) @ values[i, :fit_end]
            offset[i] = design @ coef
    residual = values - offset
    return residual[:, :, 0], residual[:, :, 1:], offset[:, :, 0]


def panel_metrics(y, pred, offset=None):
    error = np.asarray(y) - np.asarray(pred)
    sse = float(np.sum(error * error))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    result = {"MSE": float(np.mean(error * error)),
              "RMSE": float(np.sqrt(np.mean(error * error))),
              "R2": float(1.0 - sse / sst) if sst > EPS else float("nan")}
    if offset is not None:
        base = float(np.sum((y - offset) ** 2))
        result["R2_vs_deterministic_offset"] = (float(1.0 - sse / base)
                                                  if base > EPS else float("nan"))
    return result


def moving_block_ci(diff, block=14, repetitions=1000, seed=20260808):
    """Circular paired block bootstrap over time, preserving all units in a block."""
    rng = np.random.default_rng(seed)
    n, t = diff.shape
    starts = np.arange(t)
    draws = np.zeros(repetitions)
    null_draws = np.zeros(repetitions)
    observed = float(diff.mean())
    centered = diff - observed
    for b in range(repetitions):
        selected = []
        while len(selected) < t:
            start = int(rng.choice(starts))
            selected.extend(((start + np.arange(block)) % t).tolist())
        indices = np.asarray(selected[:t])
        draws[b] = float(diff[:, indices].mean())
        null_draws[b] = float(centered[:, indices].mean())
    p_value = float((1 + np.sum(np.abs(null_draws) >= abs(observed))) /
                    (repetitions + 1))
    return {"mean_loss_advantage": observed,
            "CI95": [float(np.quantile(draws, 0.025)),
                      float(np.quantile(draws, 0.975))],
            "p_two_sided": p_value,
            "block_length": int(block)}


def pivot_panel(frame, entity, date, columns):
    entities = sorted(frame[entity].dropna().unique())
    dates = pd.DatetimeIndex(sorted(pd.to_datetime(frame[date]).dropna().unique()))
    arrays = []
    for column in columns:
        table = (frame.pivot(index=entity, columns=date, values=column)
                 .reindex(index=entities, columns=dates))
        values = table.to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise ValueError(f"unbalanced or missing panel values in {column}")
        arrays.append(values)
    return entities, dates, arrays


def column_starting(frame, prefix):
    return next(column for column in frame.columns if str(column).startswith(prefix))


def load_uk_monthly():
    path = next(path for path in ROOT.glob("*97-10.xls") if "UKclimate" not in path.name)
    converted = ROOT / "external_metoffice_uk" / "supplied_uk_workbook_converted.xlsx"
    frame = pd.read_excel(converted if converted.exists() else path)
    frame["DATE"] = pd.to_datetime(dict(year=frame["year"], month=frame["month"], day=1))
    entities, dates, values = pivot_panel(frame, "station", "DATE", ["tmax", "sun", "rain", "af"])
    return {"name": "UK-monthly", "source": path, "entities": entities, "dates": dates,
            "y": values[0], "w": np.stack(values[1:], axis=2),
            "variables": ["SUN", "RAIN", "AF"],
            "data_note": "raw monthly observations; predictors are not algebraic transforms of TMAX"}


def load_china_monthly(kind="meteo"):
    path = next(ROOT.glob("Chinese*97-12*.xls"))
    converted = ROOT / "external_china" / "supplied_china_workbook_converted.xlsx"
    frame = pd.read_excel(converted if converted.exists() else path)
    tmax = column_starting(frame, "TMAX")
    if kind == "legacy":
        columns = [column_starting(frame, "CLDD"), column_starting(frame, "PRCP"),
                   column_starting(frame, "HTDD")]
        names = ["CLDD", "PRCP", "HTDD"]
        note = "legacy covariates; CLDD and HTDD are constructed from temperature and are flagged"
    else:
        columns = [column_starting(frame, "EMNT"), column_starting(frame, "EMXP"),
                   column_starting(frame, "PRCP")]
        names = ["EMNT", "EMXP", "PRCP"]
        note = "meteorological covariates not algebraically constructed from monthly TMAX"
    entities, dates, values = pivot_panel(frame, "NAME", "DATE", [tmax, *columns])
    return {"name": f"China-monthly-{kind}", "source": path, "entities": entities,
            "dates": dates, "y": values[0], "w": np.stack(values[1:], axis=2),
            "variables": names, "data_note": note}


def load_australia_daily():
    folder = ROOT / "澳洲气候"
    path = max(folder.glob("*.csv"), key=lambda item: item.stat().st_size)
    columns = ["Date", "Location", "MaxTemp", "WindSpeed3pm", "Humidity3pm", "Pressure3pm"]
    frame = pd.read_csv(path, usecols=columns, parse_dates=["Date"])
    dates = pd.date_range("2015-01-01", "2016-12-31", freq="D")
    frame = frame[(frame["Date"] >= dates[0]) & (frame["Date"] <= dates[-1])]
    complete = []
    for location, group in frame.groupby("Location"):
        aligned = group.set_index("Date").reindex(dates)
        if aligned[columns[2:]].notna().all().all():
            complete.append(location)
    frame = frame[frame["Location"].isin(sorted(complete))]
    entities, dates, values = pivot_panel(frame, "Location", "Date", columns[2:])
    if len(entities) < 10:
        raise ValueError("Australia daily panel has fewer than ten complete stations")
    return {"name": "Australia-daily-2015-2016", "source": path, "entities": entities,
            "dates": dates, "y": values[0], "w": np.stack(values[1:], axis=2),
            "variables": ["WIND3PM", "HUMIDITY3PM", "PRESSURE3PM"],
            "data_note": "ten complete stations selected solely by missingness before model fitting"}


def load_australia_monthly():
    folder = ROOT / "澳洲气候" / "月数据，12个个体"
    path = next(folder.glob("*02-15*.xls"))
    converted = (ROOT / "external_australia" /
                 "supplied_australia_workbook_converted.xlsx")
    frame = pd.read_excel(converted if converted.exists() else path)
    frame["DATE"] = pd.to_datetime(frame["DATE"])
    columns = ["TMAX", "TMIN", "EMXP", "PRCP"]
    entities, dates, values = pivot_panel(frame, "STATION", "DATE", columns)
    return {"name": "Australia-monthly-2002-2015", "source": path, "entities": entities,
            "dates": dates, "y": values[0], "w": np.stack(values[1:], axis=2),
            "variables": ["TMIN", "EMXP", "PRCP"],
            "data_note": "complete raw monthly panel; no degree-day predictor used"}


LOADERS = {
    "uk": load_uk_monthly,
    "china_meteo": lambda: load_china_monthly("meteo"),
    "china_legacy": lambda: load_china_monthly("legacy"),
    "australia_daily": load_australia_daily,
    "australia_monthly": load_australia_monthly,
}


def raw_parameters(fit):
    scale = fit["scale"]
    beta = (scale["y_sd"] * fit["beta"] / scale["z_sd"]
            if fit["beta"].size else np.empty(0))
    theta = normalize_theta(fit["theta"] / scale["x_sd"])
    return beta.tolist(), theta.tolist()


def allocation_indices(variable_count):
    if variable_count != 3:
        raise ValueError("the current comparison expects exactly three covariates")
    for z_index in range(variable_count):
        x_index = [j for j in range(variable_count) if j != z_index]
        yield x_index, [z_index]


def validation_score(data, config, fit_end, val_end, max_iter):
    yr, wr, y_offset = preprocess_panel(data["y"], data["w"], data["dates"],
                                         fit_end, config["preprocess"])
    x_idx, z_idx = config["x_idx"], config["z_idx"]
    fit = fit_scaled_multistart(yr[:, :fit_end], wr[:, :fit_end, x_idx],
                                wr[:, :fit_end, z_idx], config["h"],
                                full_starts=False, max_iter=max_iter, tol=1.0e-5)
    pred_residual = predict_scaled(fit, wr[:, fit_end:val_end, x_idx],
                                   wr[:, fit_end:val_end, z_idx])
    pred = y_offset[:, fit_end:val_end] + pred_residual
    return float(np.mean((data["y"][:, fit_end:val_end] - pred) ** 2)), fit


def select_proposed(data, outer_end, bandwidths, preprocessors, top_k=4, max_iter=18):
    last_cut = max(24, int(outer_end * 0.80))
    rows = []
    for preprocess in preprocessors:
        for x_idx, z_idx in allocation_indices(data["w"].shape[2]):
            for h in bandwidths:
                config = {"preprocess": preprocess, "x_idx": x_idx,
                          "z_idx": z_idx, "h": float(h)}
                score, fit = validation_score(data, config, last_cut, outer_end, max_iter)
                rows.append({**config, "last_fold_MSE": score,
                             "last_fold_start": fit["selected_start"],
                             "last_fold_converged": fit["converged"]})
    rows.sort(key=lambda row: row["last_fold_MSE"])
    first_cut = max(24, int(outer_end * 0.60))
    first_end = max(first_cut + 8, int(outer_end * 0.80))
    for row in rows[:min(top_k, len(rows))]:
        score, fit = validation_score(data, row, first_cut, first_end, max_iter)
        row["earlier_fold_MSE"] = score
        row["rolling_MSE"] = float((score + row["last_fold_MSE"]) / 2.0)
        row["earlier_fold_start"] = fit["selected_start"]
    finalists = [row for row in rows if "rolling_MSE" in row]
    selected = min(finalists, key=lambda row: row["rolling_MSE"])
    return selected, rows


def select_chen_bandwidth(data, outer_end, preprocess, bandwidths, max_iter=18):
    cuts = [(max(24, int(outer_end * 0.60)), int(outer_end * 0.80)),
            (max(24, int(outer_end * 0.80)), outer_end)]
    rows = []
    for h in bandwidths:
        scores = []
        for fit_end, val_end in cuts:
            yr, wr, y_offset = preprocess_panel(data["y"], data["w"], data["dates"],
                                                 fit_end, preprocess)
            empty = np.empty((data["y"].shape[0], fit_end, 0))
            fit = fit_scaled_multistart(yr[:, :fit_end], wr[:, :fit_end], empty,
                                        h, full_starts=False, max_iter=max_iter,
                                        tol=1.0e-5)
            empty_new = np.empty((data["y"].shape[0], val_end - fit_end, 0))
            pred = y_offset[:, fit_end:val_end] + predict_scaled(
                fit, wr[:, fit_end:val_end], empty_new)
            scores.append(float(np.mean((data["y"][:, fit_end:val_end] - pred) ** 2)))
        rows.append({"h": float(h), "fold_MSE": scores, "rolling_MSE": float(np.mean(scores))})
    return min(rows, key=lambda row: row["rolling_MSE"]), rows


def select_common_fe_bandwidth(data, outer_end, preprocess, x_idx, z_idx,
                               bandwidths, max_iter=18):
    """Tune Chen et al. (2013a) under the proposed model's X/Z allocation."""
    cuts = [(max(24, int(outer_end * 0.60)), int(outer_end * 0.80)),
            (max(24, int(outer_end * 0.80)), outer_end)]
    rows = []
    for h in bandwidths:
        scores = []
        starts = []
        converged = []
        failure = None
        for fit_end, val_end in cuts:
            yr, wr, y_offset = preprocess_panel(
                data["y"], data["w"], data["dates"], fit_end, preprocess)
            try:
                fit = fit_common_scaled_search(
                    yr[:, :fit_end], wr[:, :fit_end, x_idx],
                    wr[:, :fit_end, z_idx], h, max_iter=max_iter, tol=1.0e-5)
                pred = y_offset[:, fit_end:val_end] + predict_common_scaled(
                    fit, wr[:, fit_end:val_end, x_idx], wr[:, fit_end:val_end, z_idx])
                if not np.isfinite(pred).all():
                    raise FloatingPointError("non-finite Chen-2013a validation prediction")
                scores.append(float(np.mean(
                    (data["y"][:, fit_end:val_end] - pred) ** 2)))
                starts.append(fit["selected_start"])
                converged.append(fit["converged"])
            except (np.linalg.LinAlgError, FloatingPointError) as error:
                failure = f"{type(error).__name__}: {error}"
                break
        rows.append({"h": float(h), "fold_MSE": scores if failure is None else None,
                     "rolling_MSE": (float(np.mean(scores)) if failure is None else None),
                     "starts": starts, "converged": converged,
                     "failure": failure})
    valid = [row for row in rows if row["rolling_MSE"] is not None]
    if not valid:
        raise RuntimeError("all Chen-2013a bandwidth candidates failed")
    return min(valid, key=lambda row: row["rolling_MSE"]), rows


def analyse_dataset(data, bandwidths, preprocessors, outer_fraction=0.70,
                    top_k=4, search_iter=18, final_iter=60):
    y, w = data["y"], data["w"]
    outer_end = min(max(int(y.shape[1] * outer_fraction), 48), y.shape[1] - 12)
    selected, selection_rows = select_proposed(
        data, outer_end, bandwidths, preprocessors, top_k=top_k, max_iter=search_iter)
    preprocess = selected["preprocess"]
    yr, wr, y_offset = preprocess_panel(y, w, data["dates"], outer_end, preprocess)
    x_idx, z_idx = selected["x_idx"], selected["z_idx"]
    proposed = fit_scaled_multistart(yr[:, :outer_end], wr[:, :outer_end, x_idx],
                                     wr[:, :outer_end, z_idx], selected["h"],
                                     full_starts=True, max_iter=final_iter, tol=1.0e-6)
    proposed_residual, support = predict_scaled(
        proposed, wr[:, outer_end:, x_idx], wr[:, outer_end:, z_idx], True)
    proposed_pred = y_offset[:, outer_end:] + proposed_residual

    chen_selected, chen_rows = select_chen_bandwidth(
        data, outer_end, preprocess, bandwidths, max_iter=search_iter)
    empty_train = np.empty((y.shape[0], outer_end, 0))
    chen = fit_scaled_multistart(yr[:, :outer_end], wr[:, :outer_end], empty_train,
                                 chen_selected["h"], full_starts=True,
                                 max_iter=final_iter, tol=1.0e-6)
    empty_test = np.empty((y.shape[0], y.shape[1] - outer_end, 0))
    chen_pred = y_offset[:, outer_end:] + predict_scaled(
        chen, wr[:, outer_end:], empty_test)

    common_selected, common_rows = select_common_fe_bandwidth(
        data, outer_end, preprocess, x_idx, z_idx, bandwidths,
        max_iter=search_iter)
    common = fit_common_scaled_multistart(
        yr[:, :outer_end], wr[:, :outer_end, x_idx], wr[:, :outer_end, z_idx],
        common_selected["h"], full_starts=False, max_iter=final_iter, tol=1.0e-6)
    common_pred = y_offset[:, outer_end:] + predict_common_scaled(
        common, wr[:, outer_end:, x_idx], wr[:, outer_end:, z_idx])

    linear = fit_linear_fe(yr[:, :outer_end], wr[:, :outer_end])
    linear_pred = y_offset[:, outer_end:] + predict_linear_fe(linear, wr[:, outer_end:])
    offset_pred = y_offset[:, outer_end:]
    y_test = y[:, outer_end:]
    proposed_m = panel_metrics(y_test, proposed_pred, offset_pred)
    chen_m = panel_metrics(y_test, chen_pred, offset_pred)
    common_m = panel_metrics(y_test, common_pred, offset_pred)
    linear_m = panel_metrics(y_test, linear_pred, offset_pred)
    offset_m = panel_metrics(y_test, offset_pred)
    beta_raw, theta_raw = raw_parameters(proposed)
    chen_beta_raw, chen_theta_raw = raw_parameters(chen)
    common_beta_raw, common_theta_raw = raw_parameters(common)
    block = 30 if len(data["dates"]) > 400 else 6
    comparisons = {}
    for name, prediction in [("vs_Chen_2013b", chen_pred),
                             ("vs_Chen_2013a", common_pred),
                             ("vs_linear_FE", linear_pred)]:
        diff = (y_test - prediction) ** 2 - (y_test - proposed_pred) ** 2
        comparisons[name] = moving_block_ci(diff, block=block)
    effective = support["effective_test"]
    result = {
        "dataset": data["name"], "source": str(data["source"]),
        "source_sha256": hashlib.sha256(Path(data["source"]).read_bytes()).hexdigest(),
        "data_note": data["data_note"], "N": int(y.shape[0]), "T": int(y.shape[1]),
        "train_T": int(outer_end), "test_T": int(y.shape[1] - outer_end),
        "test_start": str(pd.Timestamp(data["dates"][outer_end]).date()),
        "variables": data["variables"], "preprocess": preprocess,
        "selected_allocation": {"X": [data["variables"][j] for j in x_idx],
                                "Z": [data["variables"][j] for j in z_idx]},
        "bandwidth_grid": [float(value) for value in bandwidths],
        "selected_bandwidth": float(selected["h"]),
        "bandwidth_at_grid_boundary": bool(
            selected["h"] == min(bandwidths) or selected["h"] == max(bandwidths)),
        "selection_rolling_MSE": float(selected["rolling_MSE"]),
        "selection_candidates": selection_rows,
        "chen_bandwidth_selection": chen_rows,
        "chen_common_fe_bandwidth_selection": common_rows,
        "models": {
            "proposed_RMAVE": proposed_m | {"beta_raw": beta_raw,
                                             "theta_raw": theta_raw,
                                             "selected_start": proposed["selected_start"],
                                             "iterations": proposed["iterations"],
                                             "terminal_delta": proposed["terminal_delta"],
                                             "objective": proposed["objective"]},
            "Chen_2013b_heterogeneous_SI": chen_m | {
                "beta_raw": chen_beta_raw, "theta_raw": chen_theta_raw,
                "selected_start": chen["selected_start"],
                "selected_bandwidth": float(chen_selected["h"]),
                "bandwidth_at_grid_boundary": bool(
                    chen_selected["h"] == min(bandwidths) or
                    chen_selected["h"] == max(bandwidths))},
            "Chen_2013a_common_link_FE": common_m | {
                "beta_raw": common_beta_raw, "theta_raw": common_theta_raw,
                "selected_start": common["selected_start"],
                "selected_bandwidth": float(common_selected["h"]),
                "bandwidth_at_grid_boundary": bool(
                    common_selected["h"] == min(bandwidths) or
                    common_selected["h"] == max(bandwidths)),
                "iterations": common["iterations"],
                "terminal_delta": common["terminal_delta"],
                "objective": common["objective"],
                "start_diagnostics": common["start_diagnostics"]},
            "linear_fixed_effects": linear_m | {"coef": linear["coef"].tolist()},
            "deterministic_offset": offset_m,
        },
        "start_diagnostics": proposed["start_diagnostics"],
        "support_diagnostics": {
            "outside_support_count": int(support["outside_support"].sum()),
            "test_count": int(support["outside_support"].size),
            "effective_neighbors_median": float(np.median(effective)),
            "effective_neighbors_below_3": int(np.sum(effective < 3.0)),
        },
        "paired_loss_comparisons": comparisons,
    }
    return result


def compact_row(result):
    rows = []
    for model, metrics in result["models"].items():
        rows.append({"dataset": result["dataset"], "model": model,
                     "preprocess": result["preprocess"],
                     "X": "+".join(result["selected_allocation"]["X"]),
                     "Z": "+".join(result["selected_allocation"]["Z"]),
                     "h": (result["selected_bandwidth"] if model == "proposed_RMAVE"
                           else metrics.get("selected_bandwidth", "")),
                     "MSE": metrics["MSE"], "RMSE": metrics["RMSE"], "R2": metrics["R2"],
                     "R2_vs_offset": metrics.get("R2_vs_deterministic_offset", "")})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--datasets", default="uk,china_meteo,australia_monthly")
    parser.add_argument("--output", type=Path, default=ROOT / "rmave_results_v2.json")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--outer-fraction", type=float, default=0.70)
    args = parser.parse_args()
    names = [name.strip() for name in args.datasets.split(",") if name.strip()]
    unknown = [name for name in names if name not in LOADERS]
    if unknown:
        raise ValueError(f"unknown datasets: {unknown}; available: {sorted(LOADERS)}")
    if args.quick:
        bandwidths = [0.35, 0.50, 0.75, 1.00, 1.25, 1.50]
        preprocessors = ["level", "seasonal1"]
        top_k, search_iter, final_iter = 4, 25, 50
    else:
        bandwidths = [0.10, 0.15, 0.20, 0.35, 0.50, 0.75, 1.00, 1.25,
                      1.50, 2.00, 2.50, 3.00, 4.00, 5.00]
        preprocessors = ["level", "station_mean", "seasonal1", "seasonal2"]
        top_k, search_iter, final_iter = 10, 50, 120
    results = {}
    bandwidths_by_dataset = {}
    for name in names:
        print(f"[{name}] loading", flush=True)
        data = LOADERS[name]()
        dataset_bandwidths = list(bandwidths)
        if not args.quick and name == "uk":
            dataset_bandwidths.extend([7.50, 10.00, 20.00])
        bandwidths_by_dataset[name] = dataset_bandwidths
        print(f"[{name}] N={data['y'].shape[0]} T={data['y'].shape[1]} selecting", flush=True)
        results[name] = analyse_dataset(data, dataset_bandwidths, preprocessors,
                                        outer_fraction=args.outer_fraction,
                                        top_k=top_k, search_iter=search_iter,
                                        final_iter=final_iter)
        values = results[name]["models"]["proposed_RMAVE"]
        print(f"[{name}] proposed MSE={values['MSE']:.6g} R2={values['R2']:.6g}", flush=True)
    payload = {"protocol": {
        "kernel": "Gaussian K_h(v)=phi(v/h)/h, applied once",
        "outer_fraction": args.outer_fraction, "base_bandwidths": bandwidths,
        "bandwidths_by_dataset": bandwidths_by_dataset,
        "preprocessors": preprocessors, "quick": bool(args.quick),
        "search_tolerance": 1.0e-5, "final_tolerance": 1.0e-6,
        "boundary_rule": "extend the standardized h grid in both directions before accepting a boundary optimum",
        "selection": "successive rolling-origin validation inside outer training block",
        "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
    }, "datasets": results}
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    table = pd.DataFrame([row for result in results.values() for row in compact_row(result)])
    table.to_csv(args.output.with_suffix(".csv"), index=False, encoding="utf-8-sig")
    print(table.to_string(index=False), flush=True)
    print(f"saved {args.output}", flush=True)


if __name__ == "__main__":
    main()
