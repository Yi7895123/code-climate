from __future__ import annotations
import numpy as np
from . import rmave_empirical_v2 as r2
from .preprocess_utils import metrics


def set_epan():
    r2.set_kernel('epanechnikov')


def fit_proposed(y,x,z,h,max_iter=80,tol=1e-5,full_starts=False):
    set_epan()
    return r2.fit_scaled_multistart(y,x,z,h,full_starts=full_starts,max_iter=max_iter,tol=tol)

def predict_proposed(fit,x,z):
    set_epan(); return r2.predict_scaled(fit,x,z)

def proposed_train_pred(fit):
    scale=fit['scale']; zs=(fit['training_z'] if 'training_z' in fit else None)
    # fit_rmave doesn't store standardized z. Reconstruct from residual relation:
    # y_std = residual + z beta; a is link estimate at training observations.
    # Need caller to use proposed_train_pred_from_data instead.
    raise RuntimeError('use proposed_train_pred_from_data')
def proposed_train_pred_from_data(fit,x,z):
    set_epan(); return r2.predict_scaled(fit,x,z)


def fit_chena(y,x,z,h,max_iter=80,tol=1e-5):
    # deterministic within-FE start, matching forward-CV screen.
    set_epan()
    (ys,xs,zs),scale=r2.scale_train(y,x,z)
    beta,theta=r2.within_ols_initial(ys,xs,zs)
    fit=r2.fit_common_fe_smave(ys,xs,zs,h,(beta,theta),max_iter=max_iter,tol=tol)
    fit.update({'scale':scale,'selected_start':'within_fe'})
    return fit

def predict_chena(fit,x,z):
    set_epan(); return r2.predict_common_scaled(fit,x,z)

def chena_train_pred(fit):
    z=fit['training_z']; y=fit['training_y']; scale=fit['scale']
    pred=(np.einsum('ntd,d->nt',z,fit['beta']) if z.shape[2] else np.zeros_like(y))
    pred += fit['alpha'][:,None] + fit['a'].reshape(y.shape) + fit['link_shift']
    return scale['y_mean']+scale['y_sd']*pred


def fit_ols(y,x,z):
    w=np.concatenate([x,z],axis=2)
    return r2.fit_linear_fe(y,w)
def pred_ols(fit,x,z):
    w=np.concatenate([x,z],axis=2)
    return r2.predict_linear_fe(fit,w)
