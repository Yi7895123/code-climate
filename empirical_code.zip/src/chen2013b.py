from __future__ import annotations
import numpy as np
EPS=1e-12

def normalize_theta(theta):
    theta=np.asarray(theta,float).reshape(-1)
    n=np.linalg.norm(theta)
    if not np.isfinite(n) or n<EPS: raise ValueError("invalid theta")
    theta=theta/n
    nz=np.flatnonzero(np.abs(theta)>1e-10)
    if nz.size and theta[nz[0]]<0: theta=-theta
    return theta

def kernel(delta,h):
    u=np.asarray(delta,float)/h
    out=np.zeros_like(u)
    ok=np.abs(u)<=np.sqrt(5.0)
    out[ok]=3.0/(4.0*np.sqrt(5.0))*(1-u[ok]**2/5.0)/h
    return out

def fit_linear_fe(y,x):
    yd=y-y.mean(axis=1,keepdims=True)
    xd=x-x.mean(axis=1,keepdims=True)
    coef=np.linalg.pinv(xd.reshape(-1,x.shape[2]))@yd.reshape(-1)
    alpha=(y-np.einsum('ntp,p->nt',x,coef)).mean(axis=1)
    return {"coef":coef,"alpha":alpha,"theta_init":normalize_theta(coef),
            "fitted":alpha[:,None]+np.einsum('ntp,p->nt',x,coef)}

def local_ab(y,x,theta,h, centers=None):
    n,t,p=x.shape
    u=np.einsum('ntp,p->nt',x,theta)
    if centers is None:
        centers=u
    centers=np.asarray(centers,float)
    if centers.ndim==1: centers=np.broadcast_to(centers,(n,len(centers)))
    c=centers.shape[1]
    a=np.zeros((n,c)); b=np.zeros((n,c)); f=np.zeros((n,c))
    for i in range(n):
        d=u[i,:,None]-centers[i][None,:]
        w=kernel(d,h)
        s0=w.mean(axis=0); s1=(w*d).mean(axis=0); s2=(w*d*d).mean(axis=0)
        r0=(w*y[i,:,None]).mean(axis=0); r1=(w*d*y[i,:,None]).mean(axis=0)
        det=s0*s2-s1*s1
        ridge=1e-10*np.maximum(s0+s2,1.0)
        aa=s0+ridge; cc=s2+ridge
        det2=np.maximum(aa*cc-s1*s1,EPS)
        a[i]=(cc*r0-s1*r1)/det2
        b[i]=(aa*r1-s1*r0)/det2
        f[i]=s0
    return a,b,f,u

def fit_rmave(y,x,h,tol=1e-6,max_iter=200):
    ols=fit_linear_fe(y,x)
    theta=ols['theta_init'].copy(); delta=np.inf
    n,t,p=x.shape
    for it in range(1,max_iter+1):
        old=theta.copy()
        a,b,f,u=local_ab(y,x,theta,h)
        A=np.zeros((p,p)); B=np.zeros(p)
        for i in range(n):
            Xi=x[i]
            for s in range(t):
                fis=f[i,s]
                if not np.isfinite(fis) or fis<=EPS: continue
                dx=Xi-Xi[s]
                d=dx@theta
                w=kernel(d,h)
                ww=w/fis
                bi=b[i,s]; ai=a[i,s]
                A += np.einsum('t,ti,tj->ij',ww*bi*bi,dx,dx)
                B += np.einsum('t,ti,t->i',ww*bi,dx,y[i]-ai)
        theta=normalize_theta(np.linalg.pinv(A+1e-10*np.eye(p))@B)
        if np.dot(theta,old)<0: theta=-theta
        theta=normalize_theta(theta)
        delta=float(np.linalg.norm(theta-old))
        if delta<tol: break
    a,b,f,u=local_ab(y,x,theta,h)
    return {"theta":theta,"a":a,"b":b,"fhat":f,"u":u,"h":float(h),
            "iterations":it,"terminal_delta":delta,"converged":delta<tol,
            "theta_init":ols['theta_init']}

def predict(fit,y_train,x_train,x_new):
    # Refit local linear response y_train at new index centers using final theta.
    theta=fit['theta']; h=fit['h']
    u_new=np.einsum('ntp,p->nt',x_new,theta)
    a,_,_,_=local_ab(y_train,x_train,theta,h,centers=u_new)
    return a
