"""UK application: fit four models at fixed bandwidths and compare train/test fit."""

from pathlib import Path
import argparse
import json

import numpy as np
import pandas as pd

from src.preprocess_utils import load_and_prepare, fold_preprocess, metrics
from src.model_utils import (
    fit_proposed, predict_proposed, fit_chena, predict_chena,
    chena_train_pred, fit_ols, pred_ols,
)
from src.chen2013b import fit_rmave as fit_b, predict as pred_b


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--h-proposed', type=float, default=h_proposed)
    parser.add_argument('--h-chena', type=float, default=h_Chen2013a)
    parser.add_argument('--h-chenb', type=float, default=h_Chen2013b)
    args = parser.parse_args()

    # Training: 1999–2007. Out-of-sample test: 2008.
    # Trends are fitted within station using training observations only.
    df = load_and_prepare(ROOT / 'data' / 'uk16.csv')
    data = fold_preprocess(df, 2007, 2008, x_cols=('sun', 'rain'))
    y, x, z = data['y_train'], data['x_train'], data['z_train']
    yt, xt, zt = data['y_eval'], data['x_eval'], data['z_eval']

    rows, params = [], []

    def record(method, h, train_pred, test_pred, iterations, converged):
        for sample, actual, predicted in [
            ('train_1999_2007', y, train_pred),
            ('test_2008', yt, test_pred),
        ]:
            rows.append({
                'method': method, 'h': h, 'sample': sample,
                **metrics(actual, predicted),
                'iterations': iterations, 'converged': converged,
            })

    # Proposed: individual-specific links, partial linear index.
    fit = fit_proposed(y, x, z, args.h_proposed,
                       max_iter=100, tol=1e-5, full_starts=False)
    record('Proposed', args.h_proposed,
           predict_proposed(fit, x, z), predict_proposed(fit, xt, zt),
           fit['iterations'], fit['converged'])
    params.append({
        'method': 'Proposed',
        'beta': json.dumps(fit['beta'].tolist()),
        'theta': json.dumps(fit['theta'].tolist()),
    })

    # Chen2013a: common link with fixed effects.
    fit = fit_chena(y, x, z, args.h_chena, max_iter=100, tol=1e-5)
    record('Chen2013a', args.h_chena,
           chena_train_pred(fit), predict_chena(fit, xt, zt),
           fit['iterations'], fit['converged'])
    params.append({
        'method': 'Chen2013a',
        'beta': json.dumps(fit['beta'].tolist()),
        'theta': json.dumps(fit['theta'].tolist()),
    })

    # Chen2013b: SUN, RAIN, and 11 monthly indicators all enter the index.
    x_b = np.concatenate([x, z], axis=2)
    xt_b = np.concatenate([xt, zt], axis=2)
    fit = fit_b(y, x_b, args.h_chenb, tol=1e-6, max_iter=200)
    record('Chen2013b', args.h_chenb,
           fit['a'], pred_b(fit, y, x_b, xt_b),
           fit['iterations'], fit['converged'])
    params.append({
        'method': 'Chen2013b', 'beta': '',
        'theta': json.dumps(fit['theta'].tolist()),
    })

    # OLS with individual fixed effects: no smoothing bandwidth.
    fit = fit_ols(y, x, z)
    record('OLS-FE', np.nan,
           pred_ols(fit, x, z), pred_ols(fit, xt, zt), np.nan, True)
    params.append({
        'method': 'OLS-FE',
        'beta': json.dumps(fit['coef'].tolist()), 'theta': '',
    })

    output = ROOT / 'results'
    output.mkdir(parents=True, exist_ok=True)
    table = pd.DataFrame(rows)
    table.to_csv(output / 'fixed_h_train_test_metrics.csv', index=False)
    pd.DataFrame(params).to_csv(output / 'fixed_h_parameters.csv', index=False)
    print(table.to_string(index=False))
    print('\nSaved results/fixed_h_train_test_metrics.csv and results/fixed_h_parameters.csv')


if __name__ == '__main__':
    main()
