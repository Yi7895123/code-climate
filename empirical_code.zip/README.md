# UK empirical application: estimation and pointwise inference

This folder contains the Python code needed for two parts of the UK empirical application:

1. Fit and evaluate four fixed-bandwidth models (Proposed, Chen2013a, Chen2013b, and OLS-FE).
2. Plot station-specific Proposed link estimates, pointwise confidence intervals (CIs), and diagnostic prediction intervals (PIs).

The scripts operate on the **same training observations** (1999–2007) and use 2008 only for the model-comparison test. The CI script does **not** use the 2008 test observations for inference.

> **Data required:** `data/uk16.csv` was **not included** in the supplied files and is **not distributed** in this archive. The source code and Python dependencies are collected, but the empirical results cannot be reproduced until that real dataset is provided. No simulated or substituted data are included.

## 1. File structure

```text
UK_empirical_code_package/
├── README.md
├── requirements.txt
├── four_methods.py
├── plot_UK_proposed_link_CI.py
├── data/
│   └── PLACE_DATA_HERE.txt
├── src/
│   ├── __init__.py
│   ├── preprocess_utils.py
│   ├── model_utils.py
│   ├── chen2013b.py
│   └── rmave_empirical_v2.py
└── results/                         # generated outputs (initially empty)
```

The `src` modules come from the provided `src.zip`. They include the actual model-estimation, prediction, and preprocessing functions. The unrelated `src/inference_utils.py`, compiled `__pycache__` files, and unrelated data-analysis entry points are not needed for these two scripts and are omitted. The original uploaded CI script has been renamed to `plot_UK_proposed_link_CI.py` for a portable command-line filename.

## 2. Input dataset

Copy the **actual** UK data to:

```text
data/uk16.csv
```
The data and bandwitdh will be updated when the article is officially published. 
Required CSV columns (case-sensitive):

| Column | Meaning / role |
|---|---|
| `station` | Station identifier; determines the ordering of individuals |
| `year` | Calendar year |
| `month` | Month number, 1–12 |
| `tmax` | Response variable |
| `sun` | First continuous single-index covariate |
| `rain` | Second continuous single-index covariate |


The loader requires **16 stations**, each with **120 observations** (1,920 rows in total), with no missing values in these fields. The empirical specification expects one monthly observation per station for every month of **January 1999 through December 2008**. Check that `station`–`year`–`month` combinations are unique and the entire monthly date range is present; the loader checks station counts and balance but does not separately enforce this exact date range.

No precomputed monthly dummies or preprocessed training files are required. `src/preprocess_utils.py` creates the 11 indicators `M01`–`M11`. The 12th month is the omitted reference month. It also fits station-specific linear trends for `tmax`, `sun`, and `rain` using **training years only**, and applies those training-fitted trends to 2008. The resulting outcome and continuous regressors are **detrended**, not the original raw measurement levels.

The selected specification is `X = (sun, rain)` and `Z = (M01, ..., M11)` for Proposed and Chen2013a. Chen2013b places both `X` and the 11 dummies into its index; OLS-FE fits the corresponding linear fixed-effects comparator.

## 3. Python environment

Use Python 3.13 for the provided pinned dependencies (the versions below were available in the packaging environment). From the **package root**:

```bash
python -m venv .venv
```

Activate the environment on Windows:

```powershell
.venv\Scripts\activate
```

On macOS/Linux, activate with `source .venv/bin/activate`. Then install:

```bash
python -m pip install -r requirements.txt
```

Only NumPy, pandas, Matplotlib, and the Python standard library are imported by the two entry points and their necessary modules. No R setup is required.



## 4. Run the four-method comparison

```bash
python four_methods.py
```

Default smoothing bandwidths:

| Method | Default `h` | Model implementation |
|---|---:|---|
| Proposed | h_proposed | Individual-specific link function + linear component |
| Chen2013a | h_Chen2013a | Common link with fixed effects |
| Chen2013b | h_Chen2013b | Heterogeneous single-index method |
| OLS-FE | Not applicable | Linear fixed effects |

To change the fixed values, for example:

```bash
python four_methods.py --h-proposed h_proposed --h-chena h_Chen2013a --h-chenb h_Chen2013b
```

Outputs are created automatically in `results/`:

- `fixed_h_train_test_metrics.csv`: training and test `MSE`, `RMSE`, `R2`, estimated iterations, and convergence flags.
- `fixed_h_parameters.csv`: coefficients/indices saved by each fit. The Proposed and Chen2013a parameters are stored on their internally standardized scale, whereas Chen2013b and OLS-FE use their respective unstandardized detrended designs. Do not directly compare the coefficient magnitudes without accounting for these differences.

Metrics are computed for the **detrended** outcome, not for undetrended original `tmax`. Bandwidths across implementations are not necessarily on identical kernel scales: Proposed and Chen2013a use the standard Epanechnikov kernel; the supplied Chen2013b implementation uses an Epanechnikov variant whose support is scaled by `sqrt(5)`.

## 5. Run the Proposed link-CI figures

After Step 4, run:

```bash
python plot_UK_proposed_link_CI.py
```

The defaults are station indices **3, 4, and 11**; 95% pointwise intervals (`--alpha 0.05`); the theorem plug-in standard error; the **bias-corrected** estimated link as interval center; and a pilot bandwidth equal to `h_proposed × h`. The link bandwidth is set by the variable near the top of the script:

```python
MANUAL_H_PROPOSED = h_proposed
```

The CI script loads `results/fixed_h_parameters.csv` and `results/fixed_h_train_test_metrics.csv` when available and when the saved Proposed bandwidth matches `MANUAL_H_PROPOSED`. This reuse ensures that both steps use the same fitted Proposed `beta` and `theta`. If the files are absent or the saved bandwidth differs, the CI script **refits Proposed**, with its own default stopping settings. For consistent estimation across both scripts, use the same `h` and first run Step 4.

Selected command-line options:

```bash
# Plot a different selection of station indices (1-based, sorted station order)
python plot_UK_proposed_link_CI.py --station-idx 3,5,9

# Use the exact local-linear-weight diagnostic standard error
python plot_UK_proposed_link_CI.py --ci-se local-linear

# Show an uncorrected estimated-link center instead
python plot_UK_proposed_link_CI.py --no-bias-correction

# Independently refit Proposed rather than reuse saved coefficients
python plot_UK_proposed_link_CI.py --refit

# Set a different pilot-bandwidth multiplier (for leading-bias estimation)
python plot_UK_proposed_link_CI.py --bias-bandwidth-factor h_proposed
```

Station indices refer to the **sorted station identifiers**, not an externally assigned numbering. The code writes results to `results/proposed_inference_reviewer/`, including:

- One `UK_proposed_link_..._station_*.png` per selected station: red partial-response observations, a fitted link, and its two pointwise CI limits.
- One `UK_proposed_link_..._plus_prediction_interval_...png` per station: the same curves with the two diagnostic PI limits.
- `UK_proposed_inference_points_*.csv`: pointwise coordinates, raw and bias-corrected link estimates, the selected CI center, CI/PI bounds, residuals, and diagnostics.
- `UK_proposed_inference_summary_*.csv`: per-station summaries.
- `UK_proposed_inference_metadata_*.csv`: bandwidth, kernel, inferential settings, and parameter source.

The plots retain the original supplied plotting style (red points, black solid fitted curve, and black dash-dot CI bounds). The plotted index is `theta_hat' X_it`, and the red points are the *detrended and linear-component-adjusted response* `Y_it - beta_hat' Z_it`. The code does **not** subtract `theta_hat' X_it` from the outcome. Re-expressing the standardized fitted quantities on the adjusted-response scale does **not** restore the removed station-specific linear time trends.

**Interpretation:** A pointwise CI targets the conditional link value `g_i(u)`, **not** the proportion of individual observed red points lying inside its bounds. The additional PI is an approximate interval for a **new partial response** under the variance formula in the script. Neither interval is a simultaneous confidence band. For the default Epanechnikov kernel, `mu_2(K) = 1/5` and `R(K) = 3/5`; the leading local-linear bias term subtracted from the center is `0.5 × mu_2(K) × h² × g_i''(u)`, with `g_i''` estimated by a pilot local-quadratic fit. Interval validity is subject to the model's asymptotic assumptions and the accuracy of plug-in estimates.

## 6. Packaging changes and verification status

The published-code layout includes only the files directly needed to execute the two supplied entry points. The following **implementation/interface fixes** were made without changing the core estimation formulas, initializations, model specifications, kernels, or default numerical bandwidths:

1. Both steps now use `results/` consistently; Step 4 creates it if necessary.
2. The CI script has an ASCII-only filename and retains the former default **bias-corrected** interval center. In the uploaded version, `--bias-corrected` was a no-op despite its help message. In this package, correction is explicitly enabled by default and `--no-bias-correction` disables it; the former option name remains accepted.
3. The CI metadata and CSV correctly distinguish the bias-corrected link estimate from the actually plotted center, and filenames reflect nondefault confidence levels or disabled correction.
4. Formatting and CLI organization in the comparison script were cleaned up for presentation.

**Verified:** Python syntax, import availability, required-file paths, and isolated computational/output tests with test-only data. **Not verified:** replication of the original published numerical estimates or figures, because the supplied materials did not include `uk16.csv`. Do not treat this code package as a complete data-and-results deposit until the real dataset is inserted and both scripts have been run and checked against the manuscript.
