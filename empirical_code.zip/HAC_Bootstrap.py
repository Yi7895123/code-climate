"""UK: 2008 held-out squared-loss comparison, Proposed vs Chen2013a.
Place uk16_model_ready.csv in data/ or edit DATA_FILE below.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from src.preprocess_utils import load_and_prepare, fold_preprocess
from src.model_utils import fit_proposed, predict_proposed, fit_chena, predict_chena
from paired_loss_test import paired_loss_significance

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT/'data'/'uk16_model_ready.csv'  # May be an absolute path elsewhere.
OUTPUT_DIR = ROOT/'results_comment4'
H_PROPOSED = h_proposed       # Matches corrected 04_fit_fixed_h_four_methods.py
H_CHEN2013A = h_chen2013a
BOOTSTRAP_DRAWS = 9999
BOOTSTRAP_BLOCK = 3
HAC_LAGS = 2
TEST_SEED = 24680       # Only for block resampling (not the original fit).


def main():
    if not DATA_FILE.is_file():
        raise FileNotFoundError(f'Copy your UK _model_ready.csv to {DATA_FILE} or edit DATA_FILE')
    df = load_and_prepare(DATA_FILE)
    d = fold_preprocess(df, 2007, 2008)
    y, x, z = d['y_train'], d['x_train'], d['z_train']
    ye, xe, ze = d['y_eval'], d['x_eval'], d['z_eval']

    print('Fitting UK Proposed, h =', H_PROPOSED, flush=True)
    fp = fit_proposed(y, x, z, H_PROPOSED, max_iter=100, tol=1e-5,
                      full_starts=False)
    pred_p = predict_proposed(fp, xe, ze)
    print('Fitting UK Chen2013a, h =', H_CHEN2013A, flush=True)
    fc = fit_chena(y, x, z, H_CHEN2013A, max_iter=100, tol=1e-5)
    pred_c = predict_chena(fc, xe, ze)

    N, T = ye.shape
    assert pred_p.shape == pred_c.shape == ye.shape == (16, 12)
    periods = [f'2008-{month:02d}' for month in range(1, 13)]
    paired = pd.DataFrame({
        'station': np.repeat(d['stations'], T),
        'period': np.tile(periods, N),
        'y': ye.ravel(),
        'pred_proposed': pred_p.ravel(),
        'pred_chen2013a': pred_c.ravel(),
    })
    OUTPUT_DIR.mkdir(exist_ok=True, parents=True)
    prediction_file = OUTPUT_DIR/'predictions_for_testing.csv'
    paired.to_csv(prediction_file, index=False)
    paired_loss_significance(prediction_file, OUTPUT_DIR, BOOTSTRAP_DRAWS,
                             BOOTSTRAP_BLOCK, HAC_LAGS, TEST_SEED)


if __name__ == '__main__':
    main()
